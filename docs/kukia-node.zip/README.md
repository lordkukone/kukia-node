# KUKIA Quantum AI Compute Network

**Every GPU. One intelligence network.**

Red descentralizada que conecta GPUs de hogar para ejecutar trabajo de IA
real (inferencia, imagen, video, RLVR, simulacion) y recompensa el trabajo
VERIFICADO con KUKIA Coin (KUKI).

## Concepto (30 segundos)

- Tu GPU libre → se registra como nodo → pide tareas → ejecuta → devuelve hash
- KUKIA Core verifica re-ejecutando la tarea (bit a bit) → si coincide, ganas KUKI
- La moneda NO se mina quemando electricidad (PoW). Se ACUNA con trabajo util verificado (Proof-of-Compute)
- **Sin precio hasta que la red demuestre movimiento real verificado** (decision del creador)

## Como se mina KUKI (superseguridad)

1. Core crea tarea con ID unico: tipo + parametros + semilla + timestamp
2. El nodo ejecuta en GPU y devuelve resultado + hash SHA-256
3. Core RE-EJECUTA y compara hash bit a bit. No coincide = cero pago
4. Doble titulacion en tareas criticas (2 nodos, hash cruzado)
5. Staking: nodos de confianza depositan KUKI como colateral
6. Bounty anti-trampa: cazar a un mentiroso paga 1.000 KUKI
7. Ledger encadenado (hash de bloque) - nada se altera retroactivamente

## Estructura

```
KUKIA/
├── coordinator/kukia_core.py   <- FastAPI: nodos, tareas, verificacion, ledger (puerto 8300)
├── worker/kukia_worker.py      <- Nodo GPU: pide trabajo, ejecuta, devuelve hash
├── dashboard/kukia_dash.py     <- Dashboard web en vivo (puerto 8301)
├── ledger/kukia_wallet.py      <- Billetera local (firma + saldo + historial)
├── ledger/kukia.db             <- Espina del futuro blockchain
├── docs/                       <- Whitepaper + imagenes (moneda, sello, portada)
└── tasks/                      <- Tipos de tarea
```

## Arranque rapido

```bash
# 1. Core
cd coordinator && python -m uvicorn kukia_core:app --port 8300

# 2. Dashboard
cd dashboard && python -m uvicorn kukia_dash:app --port 8301

# 3. Worker (una instancia por GPU)
cd worker && python kukia_worker.py nodo_5070   # GPU0
cd worker && python kukia_worker.py nodo_5060ti # GPU1

# 4. Wallets
cd ledger && python kukia_wallet.py nodo_fundador
```

## API

| Endpoint | Metodo | Que hace |
|---|---|---|
| /nodos/registrar | POST | Registra nodo (nombre, VRAM, ref) |
| /nodos | GET | Lista nodos |
| /tareas/crear | POST | Crea tarea (tipo, params) |
| /tareas/pendiente | GET | Nodo pide trabajo |
| /tareas/resultado | POST | Entrega hash + metricas |
| /ledger | GET | Historial de recompensas |
| /stats | GET | Supply, nodos, tareas |

## Tokenomics (propuesta)

- Maximo: 100.000.000 KUKI (fijo)
- Fundacional 25M · Nodos 40M · Equipo 15M · Gobernanza 10M · Liquidez 10M
- Expansion SOLO por gobernanza con demanda real (nunca 10.000M sin respaldo)
- Salida a precio MUY BAJO cuando la red se mueva (condiciones en whitepaper)

## Roadmap

1. Prototipo local (CORRIENDO) -> 2. Trabajo GPU real -> 3. Verificacion fuerte
-> 4. Multi-nodo -> 5. Testnet (Cosmos SDK/Arbitrum Sepolia) -> 6. Mainnet

## Honestidad

KUKIA NO promete ser la IA mas potente del mundo. Es una red util de computo
distribuido (inferencia, imagen, video, RLVR). El valor esta en trabajo
verificado, no en humo. (W: es un prototipo, no oferta de valores.)