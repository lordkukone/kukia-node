# KUKIA Node - Manual de instalacion

KUKIA es la red descentralizada de computo GPU. Tu grafica trabaja,
la red verifica el trabajo, y tu ganas KIA (la moneda del computo verificado).

## 1. Requisitos

- Windows / Linux / Mac
- Python 3.10 o superior
- GPU NVIDIA de 8GB+ (recomendado) - tambien funciona en CPU (mas lento)
- 15 minutos

## 2. Instalacion

```bash
# 1. Instala dependencias
pip install fastapi uvicorn pydantic requests torch

# 2. Arranca el COORDINADOR (solo si montas tu propio nucleo)
cd coordinator
python -m uvicorn kukia_core:app --host 0.0.0.0 --port 8300

# 3. En OTRA ventana, arranca TU WORKER (el minero)
cd worker
python kukia_worker.py tu_nombre
```

## 3. Como funciona

1. Tu worker se registra en el Core (recibe un ID de nodo y un tier por VRAM)
2. Pide tareas al Core (matrices, checksums, inferencia)
3. Ejecuta la tarea en TU GPU
4. Devuelve el resultado con un hash verificable
5. El Core verifica el hash bit a bit -> si es correcto, te paga KIA en el ledger

## 4. Economia

- Techo maximo: 100,000,000 KIA (nunca habra mas)
- Emision hasta 2150
- Recompensa base: 10 KIA por tarea verificada (x tier de tu GPU)
- Tier por VRAM: 12GB = x1.0, 16GB = x1.3, 24GB = x1.6
- Fraude (hash incorrecto) = 0 KIA + perdida de reputacion

## 5. Billetera

Tu billetera se crea automaticamente al minar:

```bash
cd ledger
python kukia_wallet.py tu_nombre
# Te muestra tu direccion KUK... unica y tu saldo
```

La clave se genera EN TU PC. Nunca sale de ella.

## 6. Dashboard

```bash
cd dashboard
python kukia_dash.py
# Abre http://127.0.0.1:8301 para ver tu red
```

## 7. Notas

- Sin precio artificial: KIA sale al mercado segun demanda real
- Fase actual: pruebas (4-6 semanas antes de apertura publica)
- Contacto: la web oficial del proyecto

KUKIA - Every GPU. One intelligence network.
