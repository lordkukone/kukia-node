"""KUKIA Core - coordinador: nodos, tareas, verificacion REAL, ledger (SQLite).

VERIFICACION: el Core NO confia en el hash del minero.
El Core recalcula la tarea el mismo (trustless) y compara el resultado
exacto. Tareas con aritmetica determinista (enteros exactos via float64
con magnitudes acotadas) para que CPU y GPU den el MISMO numero.

AUDITORIA 2026-10-18 (todas las marcas "AUDITORIA" son de esta revision):
  - Se valida la cabecera Host y el Origin (corta el DNS rebinding).
  - /tareas/pendiente exige firma Ed25519 del nodo (nadie roba la cola).
  - /tareas/resultado AUTENTICA ANTES de recalcular (no se puede quemar CPU).
  - Topes duros a params (n, pasos) y tamano del JSON.
  - Limitador por ruta (antes un solo contador bloqueaba las 5 rutas juntas).
  - Reintentos: un resultado incorrecto no mata la tarea; castiga al nodo.
  - Recuperacion de tareas atascadas en hilo propio (no dependia de que
    alguien pidiera trabajo) + /admin/liberar_atascadas.
  - Ledger con cadena de hashes verificable (/ledger/verificar).
  - monto de transferencia finito (NaN daba 500 despues de escribir).
  - /registro guarda la IP real (antes guardaba el 'ref' en su columna).
"""
import collections, hashlib, json, math, os, secrets, sqlite3, threading, uuid, time, sys, urllib.parse
from contextlib import contextmanager
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).parent.parent))
try:
    import ia_onnx_cpu as ONNXCPU  # referencia CPU (tareas embeddings)
except Exception:
    ONNXCPU = None
from fastapi import FastAPI, HTTPException, Header, Depends, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

# Lock global: SQLite NO es seguro para uso concurrente en una sola conexion.
# Todo pago pasa por este lock + BEGIN IMMEDIATE (doble proteccion).
_pago_lock = threading.Lock()

DB = Path(__file__).parent / "ledger" / "kukia.db"
DB.parent.mkdir(parents=True, exist_ok=True)

# --- Token de ADMIN: solo Kuki maneja el Core ---
# Se genera UNA vez y se guarda en un fichero local (nadie mas lo tiene).
ADMIN_TOKEN_FILE = Path(__file__).parent / "admin_token.txt"
def admin_token() -> str:
    if ADMIN_TOKEN_FILE.exists():
        return ADMIN_TOKEN_FILE.read_text(encoding="utf-8").strip()
    tok = secrets.token_hex(32)
    ADMIN_TOKEN_FILE.write_text(tok, encoding="utf-8")
    return tok

ADMIN_TOKEN = admin_token()

def exigir_admin(x_admin_token: str = Header(default="", alias="X-Admin-Token")):
    """Solo el fundador (con el token) puede administrar el Core."""
    if not secrets.compare_digest(x_admin_token or "", ADMIN_TOKEN):
        raise HTTPException(403, "solo el administrador del Core")

MAX_SUPPLY = 100_000_000          # techo fijo 100M
REWARD_BASE = 10.0                # KUKI por tarea base
# --- Bloque genesis fundacional (una sola vez) ---
GENESIS_DIR = "KUK77D72508BD940C9BA969B0402A3CF1F9679BE3"   # wallet fundador (Kuki)
GENESIS_MONTO = 15_000_000.0      # 15M reservados al fundador dentro del techo de 100M
TIER_MULT = {12: 1.0, 16: 1.3, 24: 1.6}   # Rent-Tier por VRAM (mejora 1)
REF_BONUS = 50.0                  # bonus referido al completar 10 tareas (mejora 2)
BOUNTY = 1000.0                   # bounty anti-trampa (mejora 3)
# --- Politica de firmas (migracion) ---
# False = nodos viejos sin clave siguen cobrando (compatibilidad, fase pruebas).
# True  = TODOS los nodos deben traer firma (rechaza sin clave_publica).
# Pasar a True al abrir la red publica.
EXIGIR_FIRMA_GLOBAL = True

# Tareas 'ejecutando' sin resultado tras este tiempo vuelven a 'queued'
# (recuperacion en hilo propio Y oportunista en /tareas/pendiente).
ABANDONO_SEG = 1800.0

# ============================================================
#  AUDITORIA: limites y castigos
# ============================================================
LIMITE_N = 4096            # maximo de 'n' en cualquier tarea
LIMITE_PASOS = 20000       # maximo de 'pasos' (difusion)
LIMITE_PARAMS_BYTES = 65536  # el JSON de params no puede pasar de 64 KB
MAX_FALLOS = 3             # resultados INCORRECTOS antes de cerrar la tarea
MAX_ABANDONOS = 3          # abandonos antes de cerrar la tarea como fallo
PENALIZACION = 25.0        # KIA que se le quitan al que entrega mal el trabajo
CASTIGO_SEG = 1800.0       # tiempo sin poder pedir tareas tras sabotear
PENDIENTE_EXIGIR_FIRMA = True
VENTANA_FIRMA = 300.0      # segundos de validez de la firma de 'pendiente'
_extra = [h.strip().lower() for h in (os.environ.get("KUKIA_HOSTS", "") or "").split(",") if h.strip()]
# La verificacion de 'difusion_calor' en CPU costaba 7,4 min por tarea pesada
# (habia 97 asi en la cola). Con la GPU baja a ~1 s. Sigue siendo un recalculo
# INDEPENDIENTE del minero; solo cambia donde se hace la aritmetica float64.
# Se puede desactivar con KUKIA_VERIF_GPU=0.
USAR_GPU_VERIF = os.environ.get("KUKIA_VERIF_GPU", "1") != "0"
HOSTS_PERMITIDOS = {"127.0.0.1", "localhost", "::1", "0.0.0.0"} | set(_extra)

# AUDITORIA 2026-10-19: la billetera web consulta el saldo desde el navegador.
# Antes el guardia solo aceptaba el Origin con el puerto DEL CORE (8300), asi
# que una pagina local en otro puerto (o GitHub Pages) recibia 403; y ademas
# faltaban las cabeceras CORS, con lo que el fetch fallaba igualmente.
# Ahora: vale cualquier origen de loopback (el puerto da igual), la web
# publica del proyecto, y lo que se anada en KUKIA_ORIGENES="https://a,...".
ORIGENES_PERMITIDOS = {"https://lordkukone.github.io", "null"} | {
    o.strip().lower() for o in (os.environ.get("KUKIA_ORIGENES", "") or "").split(",") if o.strip()
}

def _origen_ok(origen: str) -> bool:
    if origen in ORIGENES_PERMITIDOS:
        return True
    try:
        u = urllib.parse.urlsplit(origen)
    except Exception:
        return False
    if u.scheme not in ("http", "https"):
        return False
    return (u.hostname or "").lower() in {"127.0.0.1", "localhost", "::1"}

class _ConSegura:
    """Conexion SQLite compartida protegida con un RLock.

    AUDITORIA: sqlite3 NO deja que dos hilos usen la MISMA conexion a la vez.
    Al arrancar, las dos GPUs se registran en paralelo y saltaba
    "sqlite3.InterfaceError: bad parameter or other API misuse" -> 500 y una
    GPU se quedaba sin nodo (sin poder minar). Cada llamada va ahora bajo el
    RLock; las transacciones de escritura siguen ademas bajo _pago_lock, para
    que una transaccion entera no se pueda partir entre dos hilos.
    """
    def __init__(self, con):
        self._con = con
        self._lk = threading.RLock()

    def execute(self, sql, parametros=()):
        with self._lk:
            return self._con.execute(sql, parametros)

    def executemany(self, sql, seq):
        with self._lk:
            return self._con.executemany(sql, seq)

    def executescript(self, sql):
        with self._lk:
            return self._con.executescript(sql)

    def commit(self):
        with self._lk:
            return self._con.commit()

    def rollback(self):
        with self._lk:
            return self._con.rollback()

    def close(self):
        with self._lk:
            return self._con.close()

    @property
    def row_factory(self):
        return self._con.row_factory

    @row_factory.setter
    def row_factory(self, valor):
        self._con.row_factory = valor

con = _ConSegura(sqlite3.connect(str(DB), check_same_thread=False, timeout=10))
con.row_factory = sqlite3.Row

@contextmanager
def _escritura():
    """Escritura corta y atomica: lock + BEGIN IMMEDIATE + commit.

    AUDITORIA: /nodos/registrar, /tareas/crear y /registro escribian sin
    lock (dos peticiones a la vez podian mezclar transacciones).
    """
    with _pago_lock:
        # AUDITORIA: si otro programa tiene la base bloqueada, se reintenta una
        # vez y se responde 503 rapido (antes se quedaba esperando 30 s).
        listo = False
        for intento in (1, 2):
            try:
                con.execute("BEGIN IMMEDIATE")
                listo = True
                break
            except Exception:
                if intento == 1:
                    time.sleep(0.3)
        if not listo:
            raise HTTPException(503, "Core ocupado (la base esta bloqueada), reintentar")
        try:
            yield
            con.commit()
        except HTTPException:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            raise
        except Exception:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            raise HTTPException(500, "error interno escribiendo")

def schema():
    con.execute("CREATE TABLE IF NOT EXISTS nodos(id TEXT PRIMARY KEY, nombre TEXT, vram_gb INT, "
                "tier REAL, reputacion REAL DEFAULT 1.0, ref TEXT, tareas_ok INT DEFAULT 0, "
                "creado TEXT, tops REAL DEFAULT 0)")
    con.execute("CREATE TABLE IF NOT EXISTS tareas(id TEXT PRIMARY KEY, tipo TEXT, params TEXT, "
                "estado TEXT DEFAULT 'queued', nodo_id TEXT, resultado TEXT, hash TEXT, "
                "metrica TEXT, creado TEXT, fin TEXT, verificado INT DEFAULT 0, doble TEXT)")
    con.execute("CREATE TABLE IF NOT EXISTS ledger(id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "tarea_id TEXT, nodo_id TEXT, kuki REAL, motivo TEXT, ts TEXT)")
    con.execute("CREATE TABLE IF NOT EXISTS registros(id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "nombre TEXT, email TEXT, gpu TEXT, tops TEXT, ceder TEXT, ip TEXT, ts TEXT)")
    try:
        con.execute("ALTER TABLE nodos ADD COLUMN tops REAL DEFAULT 0")
    except Exception:
        pass
    try:
        con.execute("ALTER TABLE nodos ADD COLUMN clave_publica TEXT DEFAULT ''")
    except Exception:
        pass
    try:
        con.execute("ALTER TABLE tareas ADD COLUMN asignado REAL DEFAULT NULL")
    except Exception:
        pass
    for _sql in (
        "ALTER TABLE tareas ADD COLUMN cola TEXT DEFAULT 'B'",
        "ALTER TABLE tareas ADD COLUMN campana TEXT DEFAULT ''",
        "ALTER TABLE tareas ADD COLUMN prioridad REAL DEFAULT 0",
        "ALTER TABLE tareas ADD COLUMN vram_min INT DEFAULT 0",
        "ALTER TABLE tareas ADD COLUMN device TEXT DEFAULT ''",
        "ALTER TABLE tareas ADD COLUMN duracion_ms REAL DEFAULT 0",
        # AUDITORIA: reintentos, castigos y cadena de hashes
        "ALTER TABLE tareas ADD COLUMN intentos INT DEFAULT 0",
        "ALTER TABLE tareas ADD COLUMN nodos_intento TEXT DEFAULT ''",
        "ALTER TABLE nodos ADD COLUMN castigado_hasta REAL DEFAULT 0",
        "ALTER TABLE nodos ADD COLUMN fallos INT DEFAULT 0",
        "ALTER TABLE ledger ADD COLUMN hash_prev TEXT DEFAULT ''",
        "ALTER TABLE ledger ADD COLUMN hash TEXT DEFAULT ''",
        "ALTER TABLE registros ADD COLUMN ref TEXT DEFAULT ''",
        "ALTER TABLE nodos ADD COLUMN direccion_cobro TEXT DEFAULT ''",
    ):
        try:
            con.execute(_sql)
        except Exception:
            pass
    con.execute("CREATE TABLE IF NOT EXISTS planificador_log(id INTEGER PRIMARY KEY AUTOINCREMENT, "
                "tarea_id TEXT, nodo_id TEXT, cola TEXT, motivo TEXT, ts TEXT)")
    con.execute("CREATE TABLE IF NOT EXISTS gpu_pruebas(nodo_id TEXT, prueba TEXT, creado TEXT)")
    try:
        con.execute("ALTER TABLE nodos ADD COLUMN tops_estimado INT DEFAULT 1")
    except Exception:
        pass
    # AUDITORIA: con el generador de trabajo la tabla 'tareas' crece sola
    # (miles al dia). Sin indices, los COUNT(*) de la cola y los saldos
    # acabarian recorriendo toda la tabla.
    # ARCHIVADO (18-10-2026): la tabla 'tareas' crece con el generador
    # automatico (~500.000 filas al dia a pleno ritmo). Para poder borrar las
    # tareas viejas sin tocar el dinero ni el ritmo de emision, los totales
    # historicos viven en 'meta' y NO se recalculan contando filas.
    con.execute("CREATE TABLE IF NOT EXISTS meta(clave TEXT PRIMARY KEY, valor REAL)")
    if con.execute("SELECT valor FROM meta WHERE clave='tareas_ok_total'").fetchone() is None:
        _ok = con.execute("SELECT COUNT(*) c FROM tareas WHERE estado='ok'").fetchone()["c"]
        _prim = con.execute("SELECT MIN(fin) m FROM tareas WHERE estado='ok' AND fin IS NOT NULL").fetchone()["m"]
        try:
            _prim_e = float(time.mktime(time.strptime(_prim))) if _prim else float(time.time())
        except Exception:
            _prim_e = float(time.time())
        con.execute("INSERT INTO meta(clave,valor) VALUES('tareas_ok_total',?)", (float(_ok),))
        con.execute("INSERT OR IGNORE INTO meta(clave,valor) VALUES('primera_ok_epoch',?)", (_prim_e,))
        con.execute("INSERT OR IGNORE INTO meta(clave,valor) VALUES('tareas_archivadas',0)")
    for _ix in (
        "CREATE INDEX IF NOT EXISTS idx_tareas_estado ON tareas(estado)",
        "CREATE INDEX IF NOT EXISTS idx_tareas_cola ON tareas(estado, cola, prioridad)",
        "CREATE INDEX IF NOT EXISTS idx_tareas_nodo ON tareas(nodo_id)",
        "CREATE INDEX IF NOT EXISTS idx_tareas_campana ON tareas(campana)",
        "CREATE INDEX IF NOT EXISTS idx_tareas_creado ON tareas(creado)",
        "CREATE INDEX IF NOT EXISTS idx_ledger_nodo ON ledger(nodo_id)",
        "CREATE INDEX IF NOT EXISTS idx_ledger_motivo ON ledger(motivo)",
    ):
        try:
            con.execute(_ix)
        except Exception:
            pass
    con.commit()

schema()

def direccion_valida(d: str) -> bool:
    """Formato de direccion KUKIA: KUK + 38 hex (41 caracteres)."""
    d = (d or "").strip().upper()
    return len(d) == 41 and d.startswith("KUK") and all(c in "0123456789ABCDEF" for c in d[3:])

def _cuenta_de(nodo_id):
    """Cuenta del ledger a la que se paga/castiga un nodo: su direccion de
    cobro si la declaro al registrarse, y si no el propio id del nodo."""
    fila = con.execute("SELECT direccion_cobro FROM nodos WHERE id=?", (nodo_id,)).fetchone()
    d = ((fila["direccion_cobro"] if fila else "") or "").strip().upper()
    return d if direccion_valida(d) else nodo_id

def _asiento(tarea_id, nodo_id, kuki, motivo):
    """AUDITORIA: unico camino para escribir en el ledger. Encadena hashes:

        hash = sha256(tarea_id|nodo_id|kuki|motivo|ts|hash_prev)

    Asi un saldo retocado a mano en el .db deja de cuadrar con la cadena y
    se detecta con /ledger/verificar. Se llama SIEMPRE dentro del lock.
    """
    fila = con.execute("SELECT hash FROM ledger WHERE hash IS NOT NULL AND hash<>'' "
                       "ORDER BY id DESC LIMIT 1").fetchone()
    prev = (fila["hash"] if fila else "") or ""
    ts = time.ctime()
    base = f"{tarea_id}|{nodo_id}|{kuki}|{motivo}|{ts}|{prev}"
    h = hashlib.sha256(base.encode()).hexdigest()
    con.execute("INSERT INTO ledger(tarea_id,nodo_id,kuki,motivo,ts,hash_prev,hash) "
                "VALUES(?,?,?,?,?,?,?)", (tarea_id, nodo_id, kuki, motivo, ts, prev, h))
    return h

def genesis():
    """Asignacion fundacional: se ejecuta UNA sola vez (idempotente)."""
    ya = con.execute("SELECT COUNT(*) c FROM ledger WHERE motivo='asignacion fundacional'").fetchone()["c"]
    if not ya:
        _asiento("genesis", GENESIS_DIR, GENESIS_MONTO, "asignacion fundacional")
        con.commit()

genesis()

# ============================================================
#  VERIFICACION REAL (trustless): el Core recalcula la tarea
# ============================================================

def gen_matriz(n: int, seed: int) -> np.ndarray:
    """Matriz determinista de enteros acotados (exacta en float64)."""
    idx = np.arange(n, dtype=np.float64)
    return (idx[:, None] * 31 + idx[None, :] * 17 + seed) % 97 - 48

def computar_tarea(tipo: str, params: dict):
    """Recalcula el resultado esperado en el propio Core (numpy, CPU)."""
    if tipo == "checksum":
        data = str(params.get("data", "kukia"))
        return hashlib.sha256(data.encode()).hexdigest()
    if tipo == "matriz":
        n = int(params.get("n", 256))
        seed = int(params.get("seed", 42))
        a = gen_matriz(n, seed)
        b = gen_matriz(n, seed + 1)
        return str(int(round(float((a @ b).sum()))))
    if tipo == "inferencia":
        n = int(params.get("n", 64))
        seed = int(params.get("seed", 7))
        x = gen_matriz(n, seed)
        k = np.array([[1.0, 2.0, 1.0], [2.0, 4.0, 2.0], [1.0, 2.0, 1.0]])
        out = 0.0
        for i in range(3):
            for j in range(3):
                out += float((x[i:n-2+i, j:n-2+j] * k[i, j]).sum())
        return str(int(round(out)))
    return None

# --- Modelos de referencia para tareas IA (punto 5: distribucion) ---
MODELOS_DIR = Path(__file__).parent / "modelos"
MODELOS_DIR.mkdir(parents=True, exist_ok=True)

def _difusion_ref(n: int, pasos: int, seed: int) -> float:
    """Valor de referencia de la difusion (float64, MISMO calculo que el worker).

    AUDITORIA: en CPU (numpy) una tarea n=2048/pasos=4000 tarda ~7,4 min y la
    cola tenia 97 tareas asi (≈530 min de CPU). Con la GPU disponible baja a
    ~1 s. La rejilla inicial se genera con numpy default_rng (igual que el
    worker) y la iteracion va en float64; la comparacion sigue siendo con
    tolerancia relativa, asi que la verificacion no se debilita.
    """
    if USAR_GPU_VERIF:
        try:
            import torch
            x = torch.from_numpy(np.random.default_rng(seed).random((n, n))).to("cuda", dtype=torch.float64)
            for _ in range(pasos):
                x[1:-1, 1:-1] = x[1:-1, 1:-1] + 0.2 * (
                    x[:-2, 1:-1] + x[2:, 1:-1] + x[1:-1, :-2] + x[1:-1, 2:] - 4 * x[1:-1, 1:-1])
            return float(x.sum().item())
        except Exception:
            pass
    x = np.random.default_rng(seed).random((n, n))
    for _ in range(pasos):
        x[1:-1, 1:-1] = x[1:-1, 1:-1] + 0.2 * (
            x[:-2, 1:-1] + x[2:, 1:-1] + x[1:-1, :-2] + x[1:-1, 2:] - 4 * x[1:-1, 1:-1])
    return float(x.sum())

def _verificar_difusion(params, metrica):
    """Recomputa la difusion y compara con tolerancia relativa (GPU y CPU
    redondean distinto tras cientos de pasos)."""
    try:
        n = int(params.get("n", 256))
        pasos = int(params.get("pasos", 200))
        seed = int(params.get("seed", 42))
        val = float(metrica)
        if not math.isfinite(val):
            return False
        ref = _difusion_ref(n, pasos, seed)
        tol = float(params.get("tolerancia_rel", 1e-9))
        return abs(val - ref) <= tol * max(1.0, abs(ref))
    except Exception:
        return False

def _verificar_embeddings(tipo, params, metrica):
    """Puntos 1+2: hash del modelo + recomputo CPU con tolerancia (lote: spot-check)."""
    try:
        modelo = params["model_path"]
        vecs = json.loads(metrica)
        if not isinstance(vecs, list):
            return False
        h = ONNXCPU.config_hash(modelo, params["input"] if tipo == "embeddings" else params["inputs"])
        if str(params.get("model_hash", h)) != h:
            return False
        tol = float(params.get("tolerancia", 1e-5))
        if tipo == "embeddings":
            pares = [(params["input"], vecs)]
        else:
            entradas = list(params["inputs"])
            if len(vecs) != len(entradas):
                return False
            if len(entradas) > 3:
                import random
                idx = random.Random(int(params.get("seed", 0))).sample(range(len(entradas)), 3)
                pares = [(entradas[i], vecs[i]) for i in idx]
            else:
                pares = list(zip(entradas, vecs))
        for ent, rec in pares:
            ref = ONNXCPU.ejecutar_tarea(modelo, ent)
            if not ONNXCPU.comparar_con_tolerancia(rec, ref, tol):
                return False
        return True
    except Exception:
        return False

app = FastAPI(title="KUKIA Core", version="0.3.0")

# ============================================================
#  RATE LIMIT (anti-spam)  +  AUDITORIA: un cubo POR RUTA
# ============================================================
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request as StarRequest

# AUDITORIA: antes era un unico contador por IP compartido por las 5 rutas:
# un minero que pedia trabajo y entregaba resultados se autobloqueaba (429).
LIMITES_POR_RUTA = {
    "/registro": 30,
    "/nodos/registrar": 30,
    # Las dos rutas del minero van firmadas: el limite solo frena un bucle
    # desbocado. Con 2 GPUs el minero hace ~240 entregas/min y con 300 se
    # autofrenaba (429) en los picos.
    "/tareas/pendiente": 1200,
    "/tareas/resultado": 1200,
    "/transferir": 60,
}
RATE_WINDOW = 60.0
_rate_hist = {}
_rate_lock = threading.Lock()

class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: StarRequest, call_next):
        limite = LIMITES_POR_RUTA.get(request.url.path)
        if limite:
            ip = request.client.host if request.client else "?"
            clave = (ip, request.url.path)
            ahora = time.time()
            with _rate_lock:
                if len(_rate_hist) > 5000:      # AUDITORIA: no crecer sin freno
                    for k in [k for k, v in _rate_hist.items() if not v or ahora - v[-1] > RATE_WINDOW]:
                        _rate_hist.pop(k, None)
                hist = [t for t in _rate_hist.get(clave, []) if ahora - t < RATE_WINDOW]
                if len(hist) >= limite:
                    return JSONResponse({"detail": "demasiadas peticiones, espera un minuto"}, status_code=429)
                hist.append(ahora)
                _rate_hist[clave] = hist
        return await call_next(request)

app.add_middleware(RateLimitMiddleware)

# ============================================================
#  AUDITORIA: guardia de Host/Origin (DNS rebinding)
#  El Core vive en loopback, pero una web abierta en este PC podia
#  alcanzarlo con cualquier Host. Se rechaza lo que no sea local.
# ============================================================
class HostGuardMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: StarRequest, call_next):
        host = (request.headers.get("host") or "").split(":")[0].strip().lower()
        if host and host not in HOSTS_PERMITIDOS:
            return JSONResponse({"detail": "Host no permitido por el Core"}, status_code=403)
        origen = (request.headers.get("origin") or "").strip().lower()
        if origen and not _origen_ok(origen):
            return JSONResponse({"detail": "origen no permitido"}, status_code=403)
        return await call_next(request)

app.add_middleware(HostGuardMiddleware)

# CORS para la billetera web (lectura de saldo/estadisticas). Sin credenciales:
# las escrituras siguen exigiendo firma Ed25519 o token de admin.
app.add_middleware(
    CORSMiddleware,
    allow_origins=sorted(ORIGENES_PERMITIDOS),
    allow_origin_regex=r"^https?://(127\.0\.0\.1|localhost|\[::1\])(:\d+)?$",
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
    max_age=600,
)

class NodoIn(BaseModel):
    nombre: str
    vram_gb: int
    ref: str = ""
    tops: float = 0.0    # potencia IA declarada (TOPS, valor oficial de la GPU)
    clave_publica: str = ""  # Ed25519 hex (64 bytes) para autenticar resultados
    prueba_gpu: str = ""  # atestado GPU declarativo (punto 3, no criptografico)
    tops_estimado: bool = True  # punto 1: los TOPS son estimados por VRAM, no medidos
    # ARREGLO 2026-10-19: direccion de la billetera donde COBRAR el trabajo.
    # Antes los pagos iban siempre al id del nodo (uuid efimero): el minero
    # ganaba KIA que no llegaban nunca a su billetera y se quedaban huerfanos
    # en cada reinicio. Vacio = comportamiento antiguo (pagar al nodo).
    direccion_cobro: str = ""

class TareaIn(BaseModel):
    tipo: str      # 'checksum' | 'matriz' | 'inferencia' | 'embeddings' | 'lote_embeddings' | 'difusion_calor'
    params: dict = {}
    cola: str = "B"       # A=comercial, B=investigacion KUKIA, C=voluntaria/experimental
    campana: str = ""     # identificador de campana (para exclusion y trazabilidad)
    prioridad: float = 0.0  # dentro de la cola, mayor antes
    vram_min: int = 0     # VRAM minima (GB) que exige la tarea

def tier(vram: int) -> float:
    return TIER_MULT.get(vram, 1.0)

# --- Calendario de emision: la ultima moneda sale el 13-04-2150 ---
# 6 halvings en 124,28 anos -> era de 20,71 anos. Tras esa fecha, emision = 0.
from datetime import date, datetime, timedelta
EMISSION_START = date(2026, 1, 1)
EMISSION_END = date(2150, 4, 13)
HALVING_YEARS = (EMISSION_END - EMISSION_START).days / 365.25 / 6  # ~20,71
def emission_mult() -> float:
    """Multiplicador de recompensa por era: 1.0, 0.5, 0.25... 0 tras el 13-04-2150."""
    hoy = date.today()
    if hoy >= EMISSION_END:
        return 0.0
    elapsed = (hoy - EMISSION_START).days / 365.25
    era = max(0, int(elapsed // HALVING_YEARS))
    return 0.5 ** era

def emission_info() -> dict:
    hoy = date.today()
    if hoy >= EMISSION_END:
        return {"era_actual": 6, "multiplicador": 0.0,
                "proximo_halving": None, "fin_emision": "2150-04-13",
                "halving_years": round(HALVING_YEARS, 2)}
    elapsed = (hoy - EMISSION_START).days / 365.25
    era = max(0, int(elapsed // HALVING_YEARS))
    prox = EMISSION_START + timedelta(days=int((era + 1) * HALVING_YEARS * 365.25))
    return {
        "era_actual": era,
        "multiplicador": 0.5 ** era,
        "proximo_halving": prox.isoformat(),
        "fin_emision": "2150-04-13",
        "halving_years": round(HALVING_YEARS, 2),
    }

# ============================================================
#  AUDITORIA: validacion de params (topes duros)
# ============================================================
def validar_params(tipo: str, params: dict) -> dict:
    if not isinstance(params, dict):
        raise HTTPException(400, "params debe ser un objeto")
    if len(json.dumps(params)) > LIMITE_PARAMS_BYTES:
        raise HTTPException(400, f"params demasiado grande (max {LIMITE_PARAMS_BYTES} bytes)")
    for campo, tope in (("n", LIMITE_N), ("pasos", LIMITE_PASOS)):
        if campo in params:
            try:
                v = int(params[campo])
            except Exception:
                raise HTTPException(400, f"{campo} invalido")
            if not (1 <= v <= tope):
                raise HTTPException(400, f"{campo} fuera de rango (1..{tope})")
            params[campo] = v
    for campo in ("seed",):
        if campo in params:
            try:
                params[campo] = int(params[campo])
            except Exception:
                raise HTTPException(400, "seed invalido")
    if tipo == "checksum":
        data = str(params.get("data", "kukia"))
        if len(data) > 4096:
            raise HTTPException(400, "data demasiado larga (max 4096)")
        params["data"] = data
    if "model_path" in params and len(str(params["model_path"])) > 256:
        raise HTTPException(400, "model_path demasiado largo")
    if "inputs" in params:
        try:
            if len(params["inputs"]) > 256:
                raise HTTPException(400, "demasiadas entradas en el lote (max 256)")
        except TypeError:
            raise HTTPException(400, "inputs debe ser una lista")
    return params

def tope_default(tipo: str) -> int:
    """Tamano por defecto si la tarea no trae 'n' (para el recalculo)."""
    return 256

@app.post("/nodos/registrar")
def registrar(n: NodoIn):
    # AUDITORIA: VRAM y TOPS son autodeclarados; se acotan para que nadie
    # infle la dificultad de la red ni su tier con valores absurdos.
    vram = max(0, min(int(n.vram_gb), 512))
    tops = max(0.0, min(float(n.tops), 100_000.0))
    nid = uuid.uuid4().hex[:12]
    with _escritura():   # AUDITORIA: antes escribia sin lock (500 con 2 GPUs)
        if n.prueba_gpu:
            con.execute("INSERT INTO gpu_pruebas(nodo_id,prueba,creado) VALUES(?,?,?)",
                        (nid, n.prueba_gpu[:2000], time.ctime()))
        dir_cobro = n.direccion_cobro.strip().upper() if direccion_valida(n.direccion_cobro) else ""
        con.execute("INSERT INTO nodos(id,nombre,vram_gb,tier,reputacion,ref,creado,tops,clave_publica,tops_estimado,direccion_cobro) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                    (nid, n.nombre[:64], vram, tier(vram), 1.0, n.ref[:64], time.ctime(), tops,
                     n.clave_publica[:128], 1 if n.tops_estimado else 0, dir_cobro))
    return {"id": nid, "tier": tier(vram), "max_supply": MAX_SUPPLY, "tops_registrados": tops,
            "autenticado": bool(n.clave_publica), "direccion_cobro": dir_cobro}

class CobroIn(BaseModel):
    direccion: str
    ts: int = 0
    firma: str = ""

@app.post("/nodos/{nodo_id}/cobro")
def actualizar_cobro(nodo_id: str, c: CobroIn):
    """Cambia la direccion de cobro de un nodo ya registrado.

    Firma obligatoria con la clave del propio nodo sobre
    "cobro:<nodo>:<direccion>:<ts>" y ventana de 5 minutos: sin la clave no
    se puede desviar el pago de otro minero.
    """
    d = (c.direccion or "").strip().upper()
    if not direccion_valida(d):
        raise HTTPException(400, "direccion invalida (formato KUK + 38 hex)")
    if not c.ts or abs(time.time() - float(c.ts)) > 300:
        raise HTTPException(400, "firma caducada, reintenta")
    node = con.execute("SELECT clave_publica FROM nodos WHERE id=?", (nodo_id,)).fetchone()
    pub = ((node["clave_publica"] if node else "") or "").strip()
    if not pub:
        raise HTTPException(401, "nodo sin clave registrada")
    try:
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub)).verify(
            bytes.fromhex(c.firma), f"cobro:{nodo_id}:{d}:{c.ts}".encode())
    except Exception:
        raise HTTPException(401, "firma invalida")
    with _escritura():
        con.execute("UPDATE nodos SET direccion_cobro=? WHERE id=?", (d, nodo_id))
    return {"ok": True, "nodo_id": nodo_id, "direccion_cobro": d}

@app.get("/nodos")
def nodos():
    return [dict(r) for r in con.execute("SELECT * FROM nodos").fetchall()]

@app.get("/modelos/{nombre}")
def descargar_modelo(nombre: str):
    """Punto 5: el Core sirve el modelo de referencia; el minero lo baja si le falta."""
    seguro = Path(nombre).name
    ruta = MODELOS_DIR / seguro
    if not ruta.is_file():
        raise HTTPException(404, "modelo no disponible en el Core")
    from fastapi.responses import FileResponse
    return FileResponse(str(ruta), filename=seguro)

@app.post("/tareas/crear")
def crear_tarea(t: TareaIn, _ok: None = Depends(exigir_admin)):
    tid = uuid.uuid4().hex[:12]
    params = validar_params(t.tipo, dict(t.params or {}))
    cola = t.cola if t.cola in ("A", "B", "C") else "B"
    with _escritura():
        con.execute("INSERT INTO tareas(id,tipo,params,estado,creado,cola,campana,prioridad,vram_min) "
                    "VALUES(?,?,?,?,?,?,?,?,?)",
                    (tid, t.tipo, json.dumps(params), "queued", time.ctime(),
                     cola, t.campana[:64], float(t.prioridad), int(t.vram_min)))
    return {"tarea_id": tid, "estado": "queued"}

# ============================================================
#  AUDITORIA: recuperacion en hilo propio
#  Antes vivia SOLO dentro de /tareas/pendiente: si nadie pedia trabajo,
#  las tareas quedaban 'ejecutando' para siempre (habia 41 asi, de 50 h).
# ============================================================
def liberar_atascadas(max_abandonos: int = MAX_ABANDONOS, forzar: bool = False):
    """Devuelve a la cola las tareas 'ejecutando' cuyo asignado es viejo
    (o nulo, de versiones anteriores). Devuelve (recuperadas, cerradas)."""
    limite = time.time() - (0 if forzar else ABANDONO_SEG)
    with _pago_lock:
        try:
            con.execute("BEGIN IMMEDIATE")
        except Exception:
            return (0, 0)
        try:
            cerradas = con.execute(
                "UPDATE tareas SET estado='fallo', fin=? "
                "WHERE estado='ejecutando' AND COALESCE(asignado,0) < ? "
                "AND COALESCE(intentos,0)+1 >= ?", (time.ctime(), limite, max_abandonos))
            recuperadas = con.execute(
                "UPDATE tareas SET estado='queued', nodo_id=NULL, asignado=NULL, "
                "intentos=COALESCE(intentos,0)+1 "
                "WHERE estado='ejecutando' AND COALESCE(asignado,0) < ?", (limite,))
            con.commit()
            return (recuperadas.rowcount, cerradas.rowcount)
        except Exception:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            return (0, 0)

def _bucle_recuperacion():
    while True:
        try:
            r, c = liberar_atascadas()
            if r or c:
                print(f"[KUKIA Core] recuperacion: {r} a la cola, {c} cerradas como fallo", flush=True)
        except Exception:
            pass
        time.sleep(60)

threading.Thread(target=_bucle_recuperacion, daemon=True).start()

# AUDITORIA: se acepta GET (clientes antiguos) y POST, pero en los dos casos
# hace falta la firma del nodo. Antes bastaba un id inventado.
@app.get("/tareas/pendiente")
@app.post("/tareas/pendiente")
def pendiente(nodo_id: str, excluir: str = "", colas: str = "", ts: float = 0.0, firma: str = ""):
    """Asignacion ATOMICA: SELECT + UPDATE en una transaccion con lock.

    AUDITORIA: exige firma Ed25519 del nodo sobre "pendiente:<nodo_id>:<ts>"
    (ts en segundos, valido VENTANA_FIRMA). Antes cualquiera con un id
    inventado se llevaba tareas de la cola y las dejaba colgadas.

    POLITICA DE PRIORIDAD: cola A > B > C; dentro de cola, mayor prioridad
    antes; a igual, mas antigua antes. Solo tareas con vram_min <= VRAM del
    nodo y que ese nodo no haya fallado ya. 'excluir' = campanas separadas
    por comas. SIN desalojo: lo que ya ejecuta no se interrumpe.
    """
    node = con.execute("SELECT * FROM nodos WHERE id=?", (nodo_id,)).fetchone()
    if not node:
        raise HTTPException(404, "nodo no registrado")
    if PENDIENTE_EXIGIR_FIRMA:
        pub = (node["clave_publica"] or "") if "clave_publica" in node.keys() else ""
        if not pub:
            raise HTTPException(401, "nodo sin clave registrada (firma obligatoria)")
        if not firma:
            raise HTTPException(401, "falta firma del nodo")
        try:
            ts_f = float(ts)
        except Exception:
            raise HTTPException(401, "ts invalido")
        if abs(time.time() - ts_f) > VENTANA_FIRMA:
            raise HTTPException(401, "firma caducada (revisa el reloj)")
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
            Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub)).verify(
                bytes.fromhex(firma), f"pendiente:{nodo_id}:{int(ts_f)}".encode())
        except Exception:
            raise HTTPException(401, "firma invalida")
    try:
        castigo = float(node["castigado_hasta"] or 0.0)
    except Exception:
        castigo = 0.0
    if castigo > time.time():
        raise HTTPException(429, f"nodo castigado por resultados incorrectos durante "
                                 f"{int(castigo - time.time())} s")
    with _pago_lock:
        try:
            con.execute("BEGIN IMMEDIATE")
        except Exception:
            raise HTTPException(503, "Core ocupado, reintentar")
        try:
            # Recuperacion oportunista (el hilo lo hace igual cada 60 s)
            con.execute("UPDATE tareas SET estado='queued', nodo_id=NULL, asignado=NULL, "
                        "intentos=COALESCE(intentos,0)+1 "
                        "WHERE estado='ejecutando' AND COALESCE(asignado,0) < ?",
                        (time.time() - ABANDONO_SEG,))
            vram = int(node["vram_gb"] or 0)
            excl = [e.strip()[:64] for e in (excluir or "").split(",") if e.strip()]
            _q = ("SELECT id,tipo,params,cola,campana FROM tareas WHERE estado='queued' "
                  "AND COALESCE(vram_min,0) <= ? "
                  "AND COALESCE(nodos_intento,'') NOT LIKE ? ")
            _args = [vram, f"%{nodo_id}%"]
            if excl:
                _q += "AND COALESCE(campana,'') NOT IN (%s) " % ",".join("?" * len(excl))
                _args += excl
            _colas = [c.strip().upper() for c in (colas or "").split(",")
                      if c.strip().upper() in ("A", "B", "C")]
            if _colas:
                _q += "AND COALESCE(cola,'B') IN (%s) " % ",".join("?" * len(_colas))
                _args += _colas
            _q += ("ORDER BY CASE COALESCE(cola,'B') WHEN 'A' THEN 0 WHEN 'B' THEN 1 ELSE 2 END, "
                   "COALESCE(prioridad,0) DESC, creado LIMIT 1")
            row = con.execute(_q, _args).fetchone()
            if not row:
                con.execute("ROLLBACK")
                return {"tarea": None}
            chk = con.execute("SELECT estado FROM tareas WHERE id=?", (row["id"],)).fetchone()
            if not chk or chk["estado"] != "queued":
                con.execute("ROLLBACK")
                return {"tarea": None}
            con.execute("UPDATE tareas SET estado='ejecutando', nodo_id=?, asignado=? WHERE id=?",
                        (nodo_id, time.time(), row["id"]))
            try:
                _cola = row["cola"] or "B"
            except Exception:
                _cola = "B"
            con.execute("INSERT INTO planificador_log(tarea_id,nodo_id,cola,motivo,ts) VALUES(?,?,?,?,?)",
                        (row["id"], nodo_id, _cola,
                         f"A>B>C,prioridad,vram_min_ok(vram={vram},excl={len(excl)})", time.ctime()))
            con.commit()
            return {"tarea": {"id": row["id"], "tipo": row["tipo"], "params": json.loads(row["params"])}}
        except HTTPException:
            raise
        except Exception:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            raise HTTPException(500, "error interno asignando tarea")

@app.post("/tareas/resultado")
def resultado(tid: str, nodo_id: str, metrica: str, hash_res: str = "", firma: str = "",
              device: str = "", duracion_ms: float = 0.0, telemetria: str = ""):
    """El Core recalcula la tarea y compara el RESULTADO EXACTO (trustless).

    AUDITORIA: el orden importa. ANTES se recalculaba el resultado y DESPUES
    se miraba la firma: cualquiera (sin firma) podia quemar la CPU del Core
    con tareas pesadas. Ahora: 1) existe la tarea, 2) firma del nodo,
    3) recien entonces se recalcula, 4) transaccion de pago.

    Un resultado incorrecto ya NO condena la tarea a la primera: se cuenta
    el intento, ese nodo no la vuelve a recibir, se le castiga (reputacion,
    penalizacion en KIA y unos minutos sin tareas) y solo se cierra como
    fallo tras MAX_FALLOS intentos distintos.
    """
    # 1. Existencia y tipo (lectura sin lock)
    task = con.execute("SELECT * FROM tareas WHERE id=?", (tid,)).fetchone()
    if not task:
        raise HTTPException(404, "tarea no encontrada")
    params = json.loads(task["params"])
    tipo = task["tipo"]

    # 2. AUTENTICACION PRIMERO (vale para correctos E incorrectos)
    node = con.execute("SELECT * FROM nodos WHERE id=?", (nodo_id,)).fetchone()
    if not node:
        raise HTTPException(404, "nodo no registrado")
    pub = (node["clave_publica"] or "") if "clave_publica" in node.keys() else ""
    if EXIGIR_FIRMA_GLOBAL and not pub:
        raise HTTPException(401, "nodo sin clave registrada (firma obligatoria)")
    if pub:
        if not firma:
            raise HTTPException(401, "falta firma del nodo (suplantacion bloqueada)")
        try:
            from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
            Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub)).verify(
                bytes.fromhex(firma), f"{tid}:{metrica}".encode())
        except Exception:
            raise HTTPException(401, "firma invalida (suplantacion bloqueada)")
    # Rechazo temprano si la tarea no es pagable (evita trabajo inutil)
    if task["estado"] == "ok":
        raise HTTPException(409, "tarea ya pagada (doble pago bloqueado)")
    if task["estado"] == "fallo":
        raise HTTPException(409, "tarea ya cerrada con fallo (no reintentable)")
    if task["estado"] != "ejecutando":
        raise HTTPException(409, f"tarea en estado '{task['estado']}', no pagable")
    if task["nodo_id"] and task["nodo_id"] != nodo_id:
        raise HTTPException(409, "tarea asignada a otro nodo")

    # 3. Verificacion (ya autenticado)
    esperado = computar_tarea(tipo, params)
    _tol = (tipo in ("embeddings", "lote_embeddings") and ONNXCPU is not None) or tipo == "difusion_calor"
    if esperado is None and not _tol:
        raise HTTPException(400, "tipo de tarea no soportado")
    if tipo in ("embeddings", "lote_embeddings") and ONNXCPU is not None:
        ok = _verificar_embeddings(tipo, params, metrica)
    elif tipo == "difusion_calor":
        ok = _verificar_difusion(params, metrica)
    else:
        ok = str(metrica).strip() == str(esperado).strip()

    # 4. TRANSACCION ATOMICA con bloqueo de escritura inmediato.
    with _pago_lock:
        try:
            con.execute("BEGIN IMMEDIATE")
        except Exception:
            raise HTTPException(503, "Core ocupado, reintentar")
        try:
            task2 = con.execute("SELECT * FROM tareas WHERE id=?", (tid,)).fetchone()
            if task2["estado"] == "ok":
                con.execute("ROLLBACK")
                raise HTTPException(409, "tarea ya pagada (doble pago bloqueado)")
            if task2["estado"] == "fallo":
                con.execute("ROLLBACK")
                raise HTTPException(409, "tarea ya cerrada con fallo (no reintentable)")
            if task2["estado"] != "ejecutando":
                con.execute("ROLLBACK")
                raise HTTPException(409, f"tarea en estado '{task2['estado']}', no pagable")
            if task2["nodo_id"] and task2["nodo_id"] != nodo_id:
                con.execute("ROLLBACK")
                raise HTTPException(409, "tarea asignada a otro nodo")

            kuki = 0.0
            info_pago = {}
            if ok:
                kuki, info_pago = recompensa_pago(node["tier"])
                con.execute("UPDATE nodos SET tareas_ok=tareas_ok+1, reputacion=min(5,reputacion+0.05) "
                            "WHERE id=?", (nodo_id,))
                h = hashlib.sha256(f"{tid}:{nodo_id}:{metrica}".encode()).hexdigest()
                con.execute("UPDATE tareas SET estado='ok', hash=?, metrica=?, fin=?, verificado=1, device=?, duracion_ms=? WHERE id=?",
                            (h, metrica[:2000], time.ctime(), str(device)[:16], float(duracion_ms or 0.0), tid))
                try:
                    con.execute("CREATE TABLE IF NOT EXISTS gpu_telemetria(id INTEGER PRIMARY KEY AUTOINCREMENT, "
                                "nodo_id TEXT, device TEXT, metricas TEXT, ts TEXT, origen TEXT)")
                    if telemetria:
                        con.execute("INSERT INTO gpu_telemetria(nodo_id,device,metricas,ts,origen) VALUES(?,?,?,?,?)",
                                    (nodo_id, str(device)[:16], telemetria[:2000], time.ctime(), "worker"))
                except Exception:
                    pass
                # Contador historico: sobrevive al archivado de tareas viejas.
                con.execute("INSERT INTO meta(clave,valor) VALUES('tareas_ok_total',1) "
                            "ON CONFLICT(clave) DO UPDATE SET valor=valor+1")
                _asiento(tid, _cuenta_de(nodo_id), kuki, "trabajo verificado")
                _marcar_ok()
            else:
                # AUDITORIA: castigo + reintento en vez de cerrar la tarea
                intentos = int(task2["intentos"] or 0) + 1
                lista = (task2["nodos_intento"] or "")
                if nodo_id not in [x for x in lista.split(",") if x]:
                    lista = (lista + "," + nodo_id).strip(",")
                # penalizacion economica, sin dejar saldo negativo
                saldo = float(con.execute("SELECT COALESCE(SUM(kuki),0) s FROM ledger WHERE nodo_id=?",
                                          (nodo_id,)).fetchone()["s"] or 0.0)
                castigo_kia = min(PENALIZACION, max(0.0, saldo))
                if castigo_kia > 0:
                    _asiento(tid, _cuenta_de(nodo_id), -castigo_kia, "penalizacion por resultado incorrecto")
                con.execute("UPDATE nodos SET reputacion=max(0,reputacion-0.5), "
                            "castigado_hasta=?, fallos=COALESCE(fallos,0)+1 WHERE id=?",
                            (time.time() + CASTIGO_SEG, nodo_id))
                if intentos >= MAX_FALLOS:
                    con.execute("UPDATE tareas SET estado='fallo', fin=?, intentos=?, nodos_intento=? WHERE id=?",
                                (time.ctime(), intentos, lista, tid))
                else:
                    con.execute("UPDATE tareas SET estado='queued', nodo_id=NULL, asignado=NULL, "
                                "intentos=?, nodos_intento=? WHERE id=?", (intentos, lista, tid))
                _asiento(tid, nodo_id, 0.0, "resultado incorrecto (recalculado por el Core)")
            con.commit()
        except HTTPException:
            raise
        except Exception:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            raise HTTPException(500, "error interno en el pago")
    return {"ok": ok, "kuki": kuki, "esperado": esperado, "pago": info_pago}

@app.get("/ledger")
def ledger():
    return [dict(r) for r in con.execute("SELECT * FROM ledger ORDER BY id DESC LIMIT 200").fetchall()]

@app.get("/ledger/verificar")
def verificar_ledger():
    """AUDITORIA: comprueba la cadena de hashes del ledger.

    Devuelve los ids que no cuadran (alterados a mano en el .db). La cadena
    empieza en el primer asiento que tiene hash (los anteriores, de versiones
    sin encadenar, se ignoran)."""
    prev = ""
    n_hash = 0
    alterados = []
    for r in con.execute("SELECT id,tarea_id,nodo_id,kuki,motivo,ts,hash_prev,hash FROM ledger ORDER BY id").fetchall():
        if not r["hash"]:
            continue
        base = f"{r['tarea_id']}|{r['nodo_id']}|{r['kuki']}|{r['motivo']}|{r['ts']}|{r['hash_prev'] or ''}"
        if hashlib.sha256(base.encode()).hexdigest() != r["hash"] or (r["hash_prev"] or "") != prev:
            alterados.append(r["id"])
        prev = r["hash"]
        n_hash += 1
    total = con.execute("SELECT COUNT(*) c FROM ledger").fetchone()["c"]
    return {"asientos": total, "encadenados": n_hash, "cadena_ok": not alterados,
            "ids_alterados": alterados[:20]}

# ============================================================
#  DIFICULTAD ADAPTATIVA (potencia de LA RED KUKIA, no mundial)
#  + RECOMPENSA DINAMICA (garantiza agotar justo el 13-04-2150)
# ============================================================
REFERENCIA_TOPS = 1747.0   # red inicial (5070 + 5060 Ti): punto de calibracion
BASE_MATRIX_N = 256
BASE_INFER_N = 64

def tops_red() -> float:
    """Potencia total de la red = suma de TOPS declarados por los nodos."""
    row = con.execute("SELECT COALESCE(SUM(tops),0) s FROM nodos").fetchone()
    return float(row["s"] or 0.0)

def dificultad() -> dict:
    """Tamano de tarea segun la potencia de la red (tarea ~constante en tiempo)."""
    tops = tops_red()
    factor = 1.0 if tops <= 0 else min(4.0, max(0.5, (tops / REFERENCIA_TOPS) ** 0.5))
    return {
        "tops_red": round(tops, 1),
        "tops_referencia": REFERENCIA_TOPS,
        "factor": round(factor, 3),
        "matriz_n": min(LIMITE_N, int(BASE_MATRIX_N * factor)),
        "inferencia_n": min(LIMITE_N, int(BASE_INFER_N * factor)),
    }

def supply_emitido() -> float:
    return float(con.execute("SELECT COALESCE(SUM(kuki),0) s FROM ledger").fetchone()["s"] or 0.0)

def _epoch(ts: str) -> float:
    try:
        return time.mktime(time.strptime(ts))
    except Exception:
        return time.time()

def _meta_float(clave: str, defecto: float = 0.0) -> float:
    """Lee un contador historico de 'meta' (0/-1 si no existe o falla)."""
    try:
        row = con.execute("SELECT valor FROM meta WHERE clave=?", (clave,)).fetchone()
        return float(row["valor"]) if row else defecto
    except Exception:
        return defecto

def tasa_tareas_seg() -> float:
    """Ritmo medio real de la red (tareas OK / segundo). Minimo: 1 tarea/dia.

    ARCHIVADO: usa el contador historico de 'meta', no las filas que queden en
    'tareas'. Si contara filas, borrar tareas viejas hundiria el ritmo medido y
    el premio por tarea se dispararia al techo (emitiria demasiado deprisa).
    """
    n = _meta_float("tareas_ok_total", -1.0)
    if n < 0:  # base anterior al archivado: degradar a conteo real
        n = con.execute("SELECT COUNT(*) c FROM tareas WHERE estado='ok'").fetchone()["c"]
    if n <= 0:
        return 1.0 / 86400.0
    primera = _meta_float("primera_ok_epoch", 0.0)
    if primera <= 0:
        m = con.execute("SELECT MIN(fin) m FROM tareas WHERE estado='ok' AND fin IS NOT NULL").fetchone()["m"]
        primera = _epoch(m) if m else time.time()
    elapsed = max(3600.0, time.time() - primera)
    return max(1.0 / 86400.0, n / elapsed)


# Marcas de tiempo de las tareas OK recientes: sirven para medir el ritmo de
# AHORA. La media historica no vale: si la red acelera, la media va por detras
# y el objetivo de calendario sale alto (se emitia 18x de mas).
_ok_reciente = collections.deque(maxlen=20000)


def _marcar_ok() -> None:
    _ok_reciente.append(time.time())


def tasa_reciente(ventana: float = 180.0) -> float:
    """Tareas OK por segundo en los ultimos `ventana` segundos.

    Con menos de 20 muestras cae a la media historica (arranque del Core).
    Ventana corta a proposito: con 10 min el ritmo subia antes de que la
    ventana lo viera y se emitia de mas (1,52 KIA/min medidos frente a 1,31
    de presupuesto).
    """
    ahora = time.time()
    while _ok_reciente and ahora - _ok_reciente[0] > ventana:
        _ok_reciente.popleft()
    if len(_ok_reciente) >= 20:
        span = max(1.0, ahora - _ok_reciente[0])
        return len(_ok_reciente) / span
    return tasa_tareas_seg()

def recompensa_pago(tier: float) -> tuple:
    """Pago que garantiza: (1) nunca pasar de 100M, (2) agotar justo el 13-04-2150.

    - objetivo = restante / tareas_restantes_estimadas (persigue la fecha)
    - techo/suelo = bandas del halving x10 / x0.1 (predecible, anti-spikes)
    - pago final = min(base x tier, restante) -> el ledger JAMAS supera 100M
    """
    emit = supply_emitido()
    restante = MAX_SUPPLY - emit
    if restante <= 0:
        return 0.0, {"agotado": True}
    fin_dt = datetime(EMISSION_END.year, EMISSION_END.month, EMISSION_END.day)
    seg_rest = max(1.0, (fin_dt - datetime.now()).total_seconds())
    tasa = tasa_reciente()
    tareas_rest = max(1.0, tasa * seg_rest)
    objetivo = restante / tareas_rest
    techo = REWARD_BASE * emission_mult()
    # Pago = objetivo de calendario, punto. El techo (10 KIA x era) solo recorta
    # el caso raro de red parada; NO hay suelo. El antiguo suelo de
    # techo*0.1 (=1 KIA/tarea) era lo que agotaba los 100M en meses: con
    # ~300 tareas/min son 430.000 KIA/dia, o sea 197 dias para los 85M que
    # quedan, en vez de llegar al 13-04-2150.
    base = min(objetivo, techo) if techo > 0 else 0.0
    pago = round(min(base * tier, restante), 6)
    return pago, {"objetivo": round(objetivo, 6), "techo_halving": round(techo, 4),
                  "tasa_dia": round(tasa * 86400, 2), "restante": round(restante, 2),
                  "emision_por_min": round(restante / (seg_rest / 60.0), 4)}

@app.get("/stats")
def stats():
    sum = con.execute("SELECT COALESCE(SUM(kuki),0) as s FROM ledger").fetchone()["s"]
    sum = min(sum, MAX_SUPPLY)
    pago1, info1 = recompensa_pago(1.0)
    total_ok = int(_meta_float("tareas_ok_total", -1.0))
    if total_ok < 0:
        total_ok = con.execute("SELECT COUNT(*) c FROM tareas WHERE estado='ok'").fetchone()["c"]
    en_tabla = con.execute("SELECT COUNT(*) c FROM tareas WHERE estado='ok'").fetchone()["c"]
    return {
        "supply_emitido": sum,
        "max_supply": MAX_SUPPLY,
        "nodos": con.execute("SELECT COUNT(*) c FROM nodos").fetchone()["c"],
        # Historico real (sobrevive al archivado); 'en_tabla' son las que quedan
        # guardadas por si se quiere auditar el detalle.
        "tareas_ok": total_ok,
        "tareas_ok_en_tabla": en_tabla,
        "tareas_archivadas": int(_meta_float("tareas_archivadas", 0.0)),
        "tareas_pend": con.execute("SELECT COUNT(*) c FROM tareas WHERE estado='queued'").fetchone()["c"],
        "registros": con.execute("SELECT COUNT(*) c FROM registros").fetchone()["c"],
        "emision": emission_info(),
        "dificultad": dificultad(),
        "recompensa_base_actual": pago1,
        "pago_por_tarea": pago1,
        "emision_por_min": info1.get("emision_por_min"),
        "detalle_pago": info1,
        "auto_tareas": {"activo": AUTO_ACTIVO, "objetivo_cola": AUTO_COLA_OBJETIVO,
                        "intervalo_seg": AUTO_INTERVALO},
        "archivado": {"activo": ARCHIVAR_ACTIVO, "retencion": RETENCION_TAREAS,
                      "lote": ARCHIVAR_LOTE, "intervalo_seg": ARCHIVAR_INTERVALO},
    }

@app.post("/tareas/crear_auto")
def crear_auto(tipo: str = "matriz", _ok: None = Depends(exigir_admin)):
    """Crea una tarea con la dificultad ACTUAL de la red (tamano segun TOPS)."""
    dif = dificultad()
    tid = crear_tarea_auto(tipo)
    return {"tarea_id": tid, "estado": "queued", "dificultad": dif}

@app.post("/admin/liberar_atascadas")
def admin_liberar(_ok: None = Depends(exigir_admin)):
    """AUDITORIA: libera YA las tareas 'ejecutando' colgadas (sin esperar 30 min)."""
    forzar = True
    r, c = liberar_atascadas(forzar=True)
    return {"devueltas_a_la_cola": r, "cerradas_como_fallo": c}

# ============================================================
#  AUDITORIA 2026-10-18: generador automatico de trabajo
#  El minero no inventa tareas: solo pide trabajo. Si la cola se vacia,
#  la red se queda parada (paso de verdad: se quedo a 0 y el minero ocioso).
#  Este bucle mantiene la cola llena con la dificultad actual de la red.
#  Se apaga con KUKIA_AUTO_TAREAS=0 o desde /admin/auto_tareas.
# ============================================================
AUTO_ACTIVO = os.environ.get("KUKIA_AUTO_TAREAS", "1") != "0"
# Un colchon de 120 tareas con lote de 40 cada 10 s: el minero va a ~20
# tareas/min, asi que nunca se queda sin trabajo (con 40/20/15 se vaciaba
# entre pasadas y las GPUs esperaban).
AUTO_COLA_OBJETIVO = max(0, int(os.environ.get("KUKIA_AUTO_COLA", "120")))
AUTO_INTERVALO = max(3.0, float(os.environ.get("KUKIA_AUTO_SEG", "5")))
AUTO_POR_PASADA = max(1, int(os.environ.get("KUKIA_AUTO_LOTE", "40")))

# Trabajo variado (todas las tareas pagan lo mismo, el pago lo fija la emision):
# matriz e inferencia (aritmetica determinista), checksum y difusion de calor.
MEZCLA_AUTO = ("matriz", "matriz", "matriz", "checksum", "checksum",
               "checksum", "difusion_calor", "difusion_calor", "inferencia")

def params_auto(tipo: str) -> dict:
    """Parametros de una tarea automatica, con el tamano que toca a la red."""
    dif = dificultad()
    rnd = secrets.randbelow
    if tipo == "matriz":
        return {"n": max(64, min(LIMITE_N, int(dif["matriz_n"]))), "seed": rnd(1_000_000)}
    if tipo == "inferencia":
        return {"n": max(32, min(LIMITE_N, int(dif["inferencia_n"]))), "seed": rnd(1_000_000)}
    if tipo == "checksum":
        return {"data": "kukia-" + secrets.token_hex(12)}
    if tipo == "difusion_calor":
        # tamano moderado: el minero tarda ~0,5 s en GPU y el Core lo verifica
        # en mucho menos (antes una tarea n=2048/pasos=4000 costaba 7,4 min).
        return {"n": 1024, "pasos": 1500, "seed": rnd(1_000_000), "tolerancia_rel": 1e-9}
    raise HTTPException(400, "tipo no soportado")

def crear_tarea_auto(tipo: str = None, cola: str = "C", prioridad: float = 0.0) -> str:
    """Crea una tarea de trabajo (misma validacion que /tareas/crear)."""
    if tipo is None:
        tipo = MEZCLA_AUTO[secrets.randbelow(len(MEZCLA_AUTO))]
    params = validar_params(tipo, params_auto(tipo))
    tid = uuid.uuid4().hex[:12]
    with _escritura():
        con.execute("INSERT INTO tareas(id,tipo,params,estado,creado,cola,campana,prioridad,vram_min) "
                    "VALUES(?,?,?,?,?,?,?,?,?)",
                    (tid, tipo, json.dumps(params), "queued", time.ctime(), cola, "auto",
                     float(prioridad), 0))
    return tid

def _bucle_auto_tareas():
    """Mantiene la cola con trabajo para que el minero nunca se quede parado."""
    while True:
        try:
            if AUTO_ACTIVO and AUTO_COLA_OBJETIVO > 0:
                en_cola = con.execute("SELECT COUNT(*) c FROM tareas WHERE estado='queued'").fetchone()["c"]
                faltan = AUTO_COLA_OBJETIVO - en_cola
                if faltan > 0:
                    for _ in range(min(faltan, AUTO_POR_PASADA)):
                        crear_tarea_auto()
                    print(f"[KUKIA Core] auto-tareas: cola {en_cola} -> {en_cola + min(faltan, AUTO_POR_PASADA)}", flush=True)
        except Exception as e:
            print(f"[KUKIA Core] auto-tareas error: {e}", flush=True)
        time.sleep(AUTO_INTERVALO)

threading.Thread(target=_bucle_auto_tareas, daemon=True).start()

# ============================================================
#  ARCHIVADO DE TAREAS VIEJAS
#  A pleno ritmo (~380 tareas/min) la tabla 'tareas' mete unos 500.000
#  registros al dia (~400 MB/dia). Se borran SOLO las terminadas (ok/fallo)
#  mas antiguas, dejando las ultimas KUKIA_RETENCION_TAREAS para auditar.
#  El ledger (donde estan los saldos) NO se toca, y los contadores de 'meta'
#  conservan el historico. SQLite reutiliza las paginas libres, asi que el
#  fichero deja de crecer en cuanto alcanza el tamano de la ventana.
# ============================================================
ARCHIVAR_ACTIVO = os.environ.get("KUKIA_ARCHIVAR", "1") != "0"
RETENCION_TAREAS = max(1000, int(os.environ.get("KUKIA_RETENCION_TAREAS", "200000")))
ARCHIVAR_LOTE = max(100, int(os.environ.get("KUKIA_ARCHIVAR_LOTE", "20000")))
ARCHIVAR_INTERVALO = max(30.0, float(os.environ.get("KUKIA_ARCHIVAR_SEG", "120")))

def archivar_tareas(retencion: int = None, lote: int = None) -> dict:
    """Borra tareas terminadas antiguas, en lotes, bajo el lock de escritura."""
    ret = max(1000, int(retencion or RETENCION_TAREAS))
    bat = max(100, int(lote or ARCHIVAR_LOTE))
    corte = con.execute("SELECT rowid r FROM tareas WHERE estado IN ('ok','fallo') "
                        "ORDER BY rowid DESC LIMIT 1 OFFSET ?", (ret - 1,)).fetchone()
    if not corte:
        return {"borradas": 0, "retencion": ret, "lote": bat}
    borradas = 0
    with _pago_lock:
        try:
            con.execute("BEGIN IMMEDIATE")
        except Exception:
            return {"borradas": 0, "retencion": ret, "lote": bat,
                    "error": "base ocupada, se reintenta"}
        try:
            cur = con.execute("DELETE FROM tareas WHERE rowid IN (SELECT rowid FROM tareas "
                              "WHERE rowid < ? AND estado IN ('ok','fallo') LIMIT ?)",
                              (corte["r"], bat))
            borradas = cur.rowcount or 0
            if borradas:
                con.execute("INSERT INTO meta(clave,valor) VALUES('tareas_archivadas',?) "
                            "ON CONFLICT(clave) DO UPDATE SET valor=valor+excluded.valor", (float(borradas),))
            con.commit()
        except Exception:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            raise
    return {"borradas": borradas, "retencion": ret, "lote": bat,
            "archivadas_total": int(_meta_float("tareas_archivadas", 0.0))}

def _bucle_archivado():
    while True:
        try:
            if ARCHIVAR_ACTIVO:
                for _ in range(20):  # vaciar el atraso sin esperar a la siguiente vuelta
                    r = archivar_tareas()
                    if r.get("borradas"):
                        print(f"[KUKIA Core] archivado: {r['borradas']} tareas viejas "
                              f"(total {r['archivadas_total']})", flush=True)
                    if r.get("borradas", 0) < ARCHIVAR_LOTE or r.get("error"):
                        break
                    time.sleep(1)
        except Exception as e:
            print(f"[KUKIA Core] archivado error: {e}", flush=True)
        time.sleep(ARCHIVAR_INTERVALO)

threading.Thread(target=_bucle_archivado, daemon=True).start()

@app.post("/admin/archivar")
def admin_archivar(retencion: int = -1, lote: int = -1, _ok: None = Depends(exigir_admin)):
    """Fuerza una pasada de archivado (sin esperar al bucle)."""
    return archivar_tareas(None if retencion < 0 else retencion,
                           None if lote < 0 else lote)

@app.post("/admin/auto_tareas")
def admin_auto_tareas(activo: int = -1, objetivo: int = -1, _ok: None = Depends(exigir_admin)):
    """Enciende/apaga el generador de trabajo y fija el tamano de la cola.
    activo=1/0 y objetivo=N (tareas en cola que intenta mantener)."""
    global AUTO_ACTIVO, AUTO_COLA_OBJETIVO
    if activo >= 0:
        AUTO_ACTIVO = bool(activo)
    if objetivo >= 0:
        AUTO_COLA_OBJETIVO = int(objetivo)
    return {"activo": AUTO_ACTIVO, "objetivo_cola": AUTO_COLA_OBJETIVO,
            "intervalo_seg": AUTO_INTERVALO, "lote": AUTO_POR_PASADA}

class RegistroIn(BaseModel):
    nombre: str
    email: str
    gpu: str = ""
    tops: str = ""
    ceder_potencia: str = ""
    ref: str = ""

@app.post("/registro")
def registro(r: RegistroIn, request: Request):
    """Registro publico de la lista de espera (desde la web).

    AUDITORIA: antes el 'ref' se guardaba en la columna 'ip' y la IP real no
    se guardaba nunca. Ahora cada dato va a su columna."""
    ip = request.client.host if request.client else ""
    with _escritura():
        con.execute("INSERT INTO registros(nombre,email,gpu,tops,ceder,ref,ip,ts) VALUES(?,?,?,?,?,?,?,?)",
                    (r.nombre[:120], r.email[:160], r.gpu[:80], r.tops[:40],
                     r.ceder_potencia[:40], r.ref[:64], ip, time.ctime()))
    return {"ok": True, "mensaje": "Registrado. Te avisaremos al lanzamiento.",
            "posicion": con.execute("SELECT COUNT(*) c FROM registros").fetchone()["c"]}

@app.get("/registros")
def registros(_ok: None = Depends(exigir_admin)):
    return [dict(x) for x in con.execute("SELECT * FROM registros ORDER BY id DESC LIMIT 500").fetchall()]

@app.get("/saldo/{direccion}")
def saldo(direccion: str):
    """Saldo publico de una direccion (cualquiera puede consultarlo)."""
    s = con.execute("SELECT COALESCE(SUM(kuki),0) as s FROM ledger WHERE nodo_id=?",
                    (direccion,)).fetchone()["s"]
    return {"direccion": direccion, "saldo": s}

@app.get("/saldos")
def saldos():
    """Mapa publico direccion -> saldo (solo lectura, agregados del ledger)."""
    filas = con.execute("SELECT nodo_id, COALESCE(SUM(kuki),0) as s FROM ledger "
                        "GROUP BY nodo_id").fetchall()
    return {"saldos": {r["nodo_id"]: r["s"] for r in filas},
            "direcciones": len(filas)}

class TransferIn(BaseModel):
    de_nodo: str
    a_direccion: str
    monto: float
    nonce: str = ""
    firma: str = ""

@app.post("/transferir")
def transferir(t: TransferIn):
    """Transfiere KIA entre direcciones con firma Ed25519 y anti-repeticion.

    La firma es sobre "transferir:de:a:monto:nonce" con la clave registrada
    del nodo emisor. El nonce solo vale una vez (tabla transferencias con
    UNIQUE). Todo ocurre en una transaccion: sin saldo no hay debito ni
    credito (anti-doble-gasto). No crea moneda: debito y credito se compensan.
    """
    if not t.a_direccion or len(t.a_direccion) > 128:
        raise HTTPException(400, "destino invalido")
    if t.a_direccion == t.de_nodo:
        raise HTTPException(400, "origen y destino iguales")
    try:
        monto = round(float(t.monto), 4)
    except Exception:
        raise HTTPException(400, "monto invalido")
    # AUDITORIA: NaN esquiva "monto <= 0" y "saldo < monto" (NaN no es ni
    # mayor ni menor), y acababa escribiendo asientos NULL y devolviendo 500.
    if not math.isfinite(monto):
        raise HTTPException(400, "monto debe ser un numero finito")
    if monto <= 0:
        raise HTTPException(400, "monto debe ser positivo")
    if monto > MAX_SUPPLY:
        raise HTTPException(400, "monto mayor que el suministro total")
    if not t.nonce or len(t.nonce) > 64:
        raise HTTPException(400, "nonce invalido")
    with _pago_lock:
        try:
            con.execute("BEGIN IMMEDIATE")
        except Exception:
            raise HTTPException(503, "Core ocupado, reintentar")
        try:
            con.execute("CREATE TABLE IF NOT EXISTS transferencias(id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        "de_nodo TEXT, a_direccion TEXT, monto REAL, nonce TEXT, ts TEXT, "
                        "UNIQUE(de_nodo, nonce))")
            node = con.execute("SELECT clave_publica FROM nodos WHERE id=?", (t.de_nodo,)).fetchone()
            pub = (node["clave_publica"] if node else "") or ""
            if not pub:
                con.execute("ROLLBACK")
                raise HTTPException(401, "emisor sin clave registrada")
            if not t.firma:
                con.execute("ROLLBACK")
                raise HTTPException(401, "falta firma")
            try:
                from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
                Ed25519PublicKey.from_public_bytes(bytes.fromhex(pub)).verify(
                    bytes.fromhex(t.firma),
                    f"transferir:{t.de_nodo}:{t.a_direccion}:{monto}:{t.nonce}".encode())
            except Exception:
                con.execute("ROLLBACK")
                raise HTTPException(401, "firma invalida")
            saldo = float(con.execute("SELECT COALESCE(SUM(kuki),0) s FROM ledger WHERE nodo_id=?",
                                      (t.de_nodo,)).fetchone()["s"] or 0.0)
            if saldo < monto:
                con.execute("ROLLBACK")
                raise HTTPException(409, "saldo insuficiente")
            try:
                con.execute("INSERT INTO transferencias(de_nodo,a_direccion,monto,nonce,ts) VALUES(?,?,?,?,?)",
                            (t.de_nodo, t.a_direccion, monto, t.nonce, time.ctime()))
            except Exception:
                con.execute("ROLLBACK")
                raise HTTPException(409, "nonce ya usado (repeticion bloqueada)")
            _asiento(f"tx-{t.nonce[:12]}", t.de_nodo, -monto, "transferencia salida")
            _asiento(f"tx-{t.nonce[:12]}", t.a_direccion, monto, "transferencia entrada")
            con.commit()
            return {"ok": True, "de": t.de_nodo, "a": t.a_direccion, "monto": monto}
        except HTTPException:
            raise
        except Exception:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            raise HTTPException(500, "error interno en transferencia")

@app.get("/red/telemetria")
def red_telemetria():
    """Ultima telemetria por nodo/device (solo lectura, para el panel).
    Cada fila lleva fecha (ts) y origen. La energia es ESTIMADA."""
    try:
        filas = con.execute("SELECT nodo_id,device,metricas,ts,origen FROM gpu_telemetria "
                            "ORDER BY id DESC LIMIT 200").fetchall()
        return {"telemetria": [dict(r) for r in filas]}
    except Exception:
        return {"telemetria": []}

# el coordinador corre: uvicorn kukia_core:app --port 8300
