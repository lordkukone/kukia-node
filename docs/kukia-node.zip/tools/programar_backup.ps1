# Programa la copia diaria verificada del ledger (03:00, se recupera si el PC
# estaba apagado). Ejecutar una vez:  powershell -ExecutionPolicy Bypass -File tools\programar_backup.ps1
$ErrorActionPreference = 'Stop'
$raiz = Split-Path -Parent $PSScriptRoot
$wrapper = Join-Path $raiz 'TAREA_BACKUP.cmd'
if (-not (Test-Path $wrapper)) { throw "falta $wrapper" }

$accion = New-ScheduledTaskAction -Execute $wrapper
$disparo = New-ScheduledTaskTrigger -Daily -At 03:00
$ajustes = New-ScheduledTaskSettingsSet -StartWhenAvailable `
    -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Hours 1)

Register-ScheduledTask -TaskName 'KUKIA Backup Ledger' -Action $accion `
    -Trigger $disparo -Settings $ajustes -Force `
    -Description 'Copia diaria verificada del ledger KUKIA (conserva 14)' | Out-Null

$t = Get-ScheduledTask -TaskName 'KUKIA Backup Ledger'
$i = Get-ScheduledTaskInfo -TaskName 'KUKIA Backup Ledger'
"Tarea:  $($t.TaskName)"
"Estado: $($t.State)"
"Proxima: $($i.NextRunTime)"
"Ultima:  $($i.LastRunTime) (resultado $($i.LastTaskResult))"
