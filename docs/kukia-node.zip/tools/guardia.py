#!/usr/bin/env python3
"""Guardia: mantiene la red KUKIA viva sin que tengas que mirarla.

POR QUE EXISTE (fallo real del 20-10-2026): el minero se paro a las 12:28 y
nadie lo noto hasta las 15:00. Dos horas y media con 121 tareas en cola, la
red oficialmente "en vivo" y cero KIA acunados. Un minero que se cae y no
vuelve no es un problema de rendimiento: es la red parada.

QUE HACE, cada 30 s:
  1. Core: pide /stats. Si no responde 3 veces seguidas, lo arranca.
  2. Minero: mira si el Core paga tareas nuevas. Si no hay minero y hay cola,
     lo arranca; si en 10 min no se ha pagado nada, es que esta atascado y se
     relanza (solo mata el proceso que arranco el propio guardia; nunca el que
     abriste tu a mano).
  3. Validador: si no esta, lo arranca (si existe el binario/identidad).
  4. Publicador de metricas: idem. Sin el, la web se queda con datos viejos.

NO toca el ledger, no firma nada y no toma decisiones de dinero: solo
levanta procesos. Si se cae el propio guardia, no pasa nada: al volver a
arrancarlo revisa todo otra vez.

Uso:
    python tools/guardia.py              # bucle, para siempre
    python tools/guardia.py --una        # un solo ciclo (para probar)
    python tools/guardia.py --verbose    # explica cada comprobacion
    python tools/guardia.py --sin-minero # vigila Core/validador/publicador

Salida: 0 si todo quedo sano al terminar un ciclo, 1 si algo sigue caido.
"""
import argparse
import json
import os
import subprocess
import sys
import threading
import time
import urllib.request
from pathlib import Path

RAIZ = Path(__file__).resolve().parent.parent
LOGS = RAIZ / "logs"
LOG = LOGS / "guardia.log"


def _leer_core() -> str:
    """URL del Core: core_minero.txt (primera linea util) o 127.0.0.1:8300."""
    f = RAIZ / "core_minero.txt"
    try:
        for linea in f.read_text(encoding="utf-8", errors="replace").splitlines():
            linea = linea.strip()
            if linea and not linea.startswith("#"):
                return linea
    except Exception:
        pass
    return "http://127.0.0.1:8300"


CORE = (os.environ.get("KUKIA_CORE", "") or "").strip() or _leer_core()

# Segundos sin ningun pago nuevo para considerar que el minero no trabaja.
ATASCO_SEG = float(os.environ.get("KUKIA_GUARDIA_ATASCO", "600"))
# Cada cuanto se intenta anclar el ultimo sello en Bitcoin (OpenTimestamps).
ANCLA_SEG = float(os.environ.get("KUKIA_GUARDIA_ANCLA", "600"))
# Fallos seguidos del Core antes de relanzarlo.
FALLOS_CORE = 3
# Si hay mas de estas tareas en cola y no hay minero nuestro vivo, se arranca.
ATASCO_COLA_MIN = 5
INTERVALO = float(os.environ.get("KUKIA_GUARDIA_INTERVALO", "30"))
MAX_LOG_BYTES = 5 * 1024 * 1024


def log(msg: str) -> None:
    linea = time.strftime("%Y-%m-%d %H:%M:%S") + "  " + msg
    print(linea, flush=True)
    try:
        LOGS.mkdir(parents=True, exist_ok=True)
        if LOG.exists() and LOG.stat().st_size > MAX_LOG_BYTES:
            LOG.replace(LOG.with_suffix(".log.1"))
        with LOG.open("a", encoding="utf-8") as f:
            f.write(linea + "\n")
    except Exception:
        pass


def _peticion(ruta: str, timeout: float = 6.0):
    with urllib.request.urlopen(CORE + ruta, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", "replace"))


def _py() -> str:
    return sys.executable or "python"


def _puerto_abierto(timeout: float = 2.0) -> bool:
    """True si hay algo escuchando en el host/puerto del Core.

    Sirve para no lanzar un uvicorn duplicado cuando el Core ya existe pero
    esta devolviendo errores: el segundo moriria al no poder enlazar el
    puerto y solo llenaria el log.
    """
    try:
        from urllib.parse import urlsplit
        import socket
        u = urlsplit(CORE)
        host = u.hostname or "127.0.0.1"
        puerto = u.port or (443 if u.scheme == "https" else 80)
        with socket.create_connection((host, puerto), timeout=timeout):
            return True
    except Exception:
        return False


_YA_CORRIENDO = {}


def _contar_procesos(patron: str, excluir_pid: int = 0) -> int:
    """Cuantos procesos (aparte del nuestro) llevan `patron` en su linea.

    Solo se miran python.exe: si se mira todo el sistema, el propio PowerShell
    de la consulta aparece porque el patron va escrito en su linea de comandos
    (fue un fallo real: el guardia se creia que el minero seguia vivo).
    """
    try:
        if os.name == "nt":
            ps = ("Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
                  f"Where-Object {{ $_.CommandLine -like '*{patron}*' -and "
                  f"$_.ProcessId -ne {int(excluir_pid)} }} | "
                  "Select-Object -ExpandProperty ProcessId")
            r = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                               capture_output=True, text=True, timeout=20)
            return len([l for l in r.stdout.splitlines() if l.strip()])
        r = subprocess.run(["ps", "-eo", "pid=,args="], capture_output=True,
                           text=True, timeout=10)
        n = 0
        for linea in r.stdout.splitlines():
            partes = linea.strip().split(None, 1)
            if len(partes) == 2 and patron in partes[1] and partes[0] != str(excluir_pid):
                n += 1
        return n
    except Exception:
        return 0


def _ya_corriendo(patron: str, ttl: float = 20.0) -> bool:
    """True si YA hay un proceso abierto aparte que hace ese trabajo.

    Sin esto el guardia duplicaba todo: arrancaba un segundo publicador y un
    segundo validador sobre los que ya estaban abiertos a mano.

    FALLO REAL (20-10-2026): la consulta de Windows se buscaba a si misma. La
    linea de comandos del PowerShell que filtraba contenia el texto
    'kukia_worker.py', asi que salia siempre "ya esta corriendo" y el guardia
    no relanzo el minero caido en 90 s. Ahora solo se miran procesos
    python.exe y se excluye el propio PID.

    El resultado se cachea 20 s: en Windows cada consulta cuesta ~0,5 s y en
    un bucle de 30 s no hace falta preguntar mas.
    """
    ahora = time.time()
    cache = _YA_CORRIENDO.get(patron)
    if cache and ahora - cache[0] < ttl:
        return cache[1]
    encontrado = False
    try:
        if os.name == "nt":
            ps = ("Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
                  "Where-Object { $_.CommandLine -like "
                  f"'*{patron}*' -and $_.ProcessId -ne $PID }} | "
                  "Select-Object -ExpandProperty ProcessId")
            r = subprocess.run(["powershell", "-NoProfile", "-Command", ps],
                               capture_output=True, text=True, timeout=20)
            encontrado = bool(r.stdout.strip())
        else:
            r = subprocess.run(["ps", "-eo", "pid=,args="], capture_output=True,
                               text=True, timeout=10)
            encontrado = any(patron in l and str(os.getpid()) not in l.split()[:1]
                             for l in r.stdout.splitlines())
    except Exception:
        encontrado = False
    _YA_CORRIENDO[patron] = (ahora, encontrado)
    return encontrado


class Hijo:
    """Proceso que arranca el guardia. Solo se mata lo que arrancamos nosotros."""

    def __init__(self, nombre: str, argv: list, cwd: Path, logfile: Path):
        self.nombre = nombre
        self.argv = argv
        self.cwd = cwd
        self.logfile = logfile
        self.proc = None
        self.arranques = 0
        self.ultimo_arranque = 0.0
        self.patron = nombre

    def vivo(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def arrancar(self) -> bool:
        """Arranca el proceso. True si esta vuelta ha lanzado algo de verdad."""
        # Nunca mas de un arranque cada 20 s: si algo esta roto de verdad
        # (falta una dependencia), no queremos 180 intentos por hora.
        if time.time() - self.ultimo_arranque < 20:
            return False
        # Si el usuario ya tiene uno abierto, no se arranca otro.
        if not self.vivo() and _ya_corriendo(PATRONES[self.nombre]):
            log(f"[{self.nombre}] ya esta corriendo (abierto aparte): no se duplica")
            self.ultimo_arranque = time.time()
            return False
        self.detener()
        try:
            LOGS.mkdir(parents=True, exist_ok=True)
            salida = self.logfile.open("ab")
            extra = {}
            if os.name == "nt":
                extra["creationflags"] = 0x08000000  # CREATE_NO_WINDOW
            self.proc = subprocess.Popen(
                self.argv, cwd=str(self.cwd), stdout=salida, stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL, **extra)
            self.arranques += 1
            self.ultimo_arranque = time.time()
            log(f"[{self.nombre}] arrancado pid={self.proc.pid}")
            return True
        except Exception as e:
            self.ultimo_arranque = time.time()
            log(f"[{self.nombre}] ERROR al arrancar: {type(e).__name__}: {e}")
            return False

    def detener(self) -> None:
        if self.proc is not None and self.proc.poll() is None:
            try:
                self.proc.terminate()
                self.proc.wait(timeout=10)
            except Exception:
                try:
                    self.proc.kill()
                except Exception:
                    pass
        self.proc = None


PATRONES = {
    "core": "kukia_core",
    "validador": "kukia_validator.py",
    "publicador": "publicar_metricas.py",
    "minero": "kukia_worker.py",
    "panel": "kukia_dash",
}


def construir_hijos(sin_minero: bool) -> dict:
    hijos = {}
    hijos["core"] = Hijo(
        "core", [_py(), "-m", "uvicorn", "kukia_core:app", "--host", "127.0.0.1", "--port", "8300"],
        RAIZ / "coordinator", LOGS / "core.log")
    if (RAIZ / "validator" / "kukia_validator.py").exists():
        ident = RAIZ / "validator" / "identidad_validador.json"
        hijos["validador"] = Hijo(
            "validador",
            [_py(), "-u", str(RAIZ / "validator" / "kukia_validator.py"), "--core", CORE,
             "--nombre", "VALIDADOR_KUKI", "--identidad", str(ident), "--intervalo", "60"],
            RAIZ, LOGS / "validador.log")
    if (RAIZ / "dashboard" / "kukia_dash.py").exists():
        hijos["panel"] = Hijo(
            "panel", [_py(), "-m", "uvicorn", "kukia_dash:app", "--host", "127.0.0.1",
                      "--port", "8301"],
            RAIZ / "dashboard", LOGS / "panel.log")
    if (RAIZ / "publico" / "publicar_metricas.py").exists():
        hijos["publicador"] = Hijo(
            "publicador",
            [_py(), "-u", str(RAIZ / "publico" / "publicar_metricas.py")],
            RAIZ, LOGS / "publicador.log")
    if not sin_minero and (RAIZ / "worker" / "kukia_worker.py").exists():
        # El log del minero va a worker/minero.log y NO a logs/: es el fichero
        # que lee el publicador de metricas para calcular los GFLOPS por GPU.
        # Con otra ruta, la web se quedaba sin potencia medida (paso el
        # 20-10-2026: el publicador leia un log que ya nadie escribia).
        hijos["minero"] = Hijo(
            "minero", [_py(), "-u", "kukia_worker.py", "minero_pc"],
            RAIZ / "worker", RAIZ / "worker" / "minero.log")
    return hijos


def _hilo_anclaje() -> None:
    """Ancla sellos en Bitcoin y completa las pruebas pendientes, en segundo plano.

    Abrir un anclaje cada 10 min es barato (unos cientos de bytes a tres
    calendarios). Si ya esta anclado, el script lo dice y no hace nada: solo se
    escribe en el log cuando hay algo nuevo de verdad.
    """
    time.sleep(25)
    script = RAIZ / "tools" / "anclar_ots.py"
    if not script.exists():
        return
    while True:
        try:
            for modo in (None, "--actualizar"):
                argv = [_py(), str(script)] + ([modo] if modo else [])
                r = subprocess.run(argv, cwd=str(RAIZ), capture_output=True,
                                   text=True, timeout=240)
                lineas = [l for l in (r.stdout or "").splitlines() if l.strip()]
                interesantes = [l for l in lineas
                                if "enviado a" in l or "CONFIRMADO" in l
                                or "OK en bloque" in l or "FALLO" in l
                                or "ERROR" in l]
                for l in interesantes:
                    log(f"[ancla] {l.lstrip('[ancla] ').strip()}")
        except Exception as e:
            log(f"[ancla] error: {type(e).__name__}: {e}")
        time.sleep(ANCLA_SEG)


class Estado:
    def __init__(self):
        self.fallos_core = 0
        self.ultimo_ok_tareas = None
        self.ultimo_ok_ts = 0.0
        self.tareas_previas = None

    def core_sano(self) -> dict:
        try:
            d = _peticion("/stats")
            self.fallos_core = 0
            return d or {}
        except Exception as e:
            self.fallos_core += 1
            log(f"[core] no responde ({type(e).__name__}) fallo {self.fallos_core}/{FALLOS_CORE}")
            return {}

    def progreso(self, stats: dict, verbose: bool) -> bool:
        """True si el Core ha pagado tareas nuevas desde la ultima vuelta."""
        try:
            ok = int(stats.get("tareas_ok") or 0)
        except Exception:
            return True
        ahora = time.time()
        if self.tareas_previas is None or ok > self.tareas_previas:
            if self.tareas_previas is not None and ok > self.tareas_previas:
                self.ultimo_ok_ts = ahora
            self.tareas_previas = ok
            if self.ultimo_ok_ts == 0.0:
                self.ultimo_ok_ts = ahora
            return True
        en_cola = int(stats.get("tareas_pend") or 0)
        if en_cola <= 0:
            return True
        sin_pagar = ahora - self.ultimo_ok_ts
        if verbose:
            log(f"[minero] sin pagos desde hace {sin_pagar:.0f} s (cola {en_cola})")
        return sin_pagar < ATASCO_SEG


def ciclo(hijos: dict, estado: Estado, verbose: bool) -> int:
    problemas = 0

    # 1. Core
    stats = estado.core_sano()
    if not stats:
        if estado.fallos_core >= FALLOS_CORE:
            if _puerto_abierto():
                log("[core] el puerto responde pero /stats falla: no se lanza otro "
                    "Core (revisa logs/core.log)")
            elif hijos["core"].arrancar():
                problemas += 1
        return problemas

    # 2. Minero: la senal de vida NO es que el proceso exista, es que el Core
    #    pague tareas nuevas. Un minero vivo pero atascado (CUDA colgada) no
    #    sirve de nada y hay que relanzarlo igual.
    minero = hijos.get("minero")
    if minero is not None:
        progresando = estado.progreso(stats, verbose)
        cola = int(stats.get("tareas_pend") or 0)
        if not progresando:
            log(f"[minero] {ATASCO_SEG:.0f} s sin cobrar con cola {cola}: relanzando")
            if minero.vivo():
                minero.detener()          # el nuestro: se mata y se relanza
            if minero.arrancar():         # si es de otro, arrancar() no duplica
                problemas += 1
            estado.ultimo_ok_ts = time.time()   # margen para que arranque
        elif not minero.vivo() and cola > ATASCO_COLA_MIN:
            # Nadie mina por nuestra parte y hay trabajo esperando.
            if minero.arrancar():
                problemas += 1

    # 3. Validador y publicador: solo hay que mantenerlos vivos.
    for nombre in ("validador", "publicador", "panel"):
        h = hijos.get(nombre)
        if h is not None and not h.vivo():
            if h.arrancar():
                problemas += 1

    if verbose:
        log(f"[ok] nodos={stats.get('nodos')} cola={stats.get('tareas_pend')} "
            f"tareas_ok={stats.get('tareas_ok')}")
    return problemas


def main() -> int:
    ap = argparse.ArgumentParser(description="Guardia de procesos KUKIA")
    ap.add_argument("--una", action="store_true", help="un solo ciclo y sale")
    ap.add_argument("--verbose", action="store_true", help="detalle en el log")
    ap.add_argument("--sin-minero", action="store_true", help="no vigilar el minero")
    args = ap.parse_args()

    # CANDADO DE INSTANCIA UNICA. Tres guardias a la vez no duplican procesos
    # (cada uno comprueba antes), pero si el minero se cae, los tres lo
    # relanzan a la vez y acabas con tres mineros peleando por la misma GPU.
    if not args.una:
        otros = _contar_procesos("tools/guardia.py", excluir_pid=os.getpid())
        if otros > 0:
            log(f"ya hay {otros} guardia(s) corriendo: esta no arranca "
                f"(mata la otra o usa --una para un ciclo suelto)")
            return 0

    hijos = construir_hijos(args.sin_minero)
    estado = Estado()
    if not args.una:
        threading.Thread(target=_hilo_anclaje, daemon=True).start()
    log(f"guardia arrancada (core={CORE}, intervalo={INTERVALO:.0f}s, "
        f"atasco={ATASCO_SEG:.0f}s)")

    if args.una:
        # En modo prueba se mira una vez y se sale, sin dejar hijos colgando.
        p = ciclo(hijos, estado, True)
        log(f"un ciclo: {p} incidencias")
        for h in hijos.values():
            h.detener()
        return 0 if p == 0 else 1

    problemas = 0
    try:
        while True:
            problemas = ciclo(hijos, estado, args.verbose)
            time.sleep(INTERVALO)
    except KeyboardInterrupt:
        log("guardia detenida por el usuario")
    finally:
        for h in hijos.values():
            h.detener()
    return 0 if problemas == 0 else 1


if __name__ == "__main__":
    for _f in (sys.stdout, sys.stderr):
        try:
            _f.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    raise SystemExit(main())
