"""KUKIA Worker - minero multi-GPU: se registra, pide trabajo, ejecuta en GPU.

VERIFICACION REAL: el worker calcula el resultado (no un hash propio) y el
Core lo recalcula y compara. El worker NO puede falsificar: si el numero no
coincide exactamente con el recalculado por el Core, no cobra.

MULTI-GPU: usa TODAS las GPUs disponibles a la vez (una cola por GPU).

AUDITORIA 2026-10-18:
  - Implementado 'difusion_calor' (antes devolvia el literal
    "tarea_no_soportada": habia 97 tareas de ese tipo que era imposible
    cobrar y cada intento costaba minutos de CPU al Core).
  - /tareas/pendiente exige firma del nodo ("pendiente:<id>:<ts>").
  - Se leen los codigos 401/403/429 del Core y se informa en claro
    (antes un 429 reventaba con KeyError y solo ponia "err").
  - El resultado de difusion va como numero con toda la precision
    (float64), que es lo que el Core verifica con tolerancia relativa.
"""
import hashlib, json, os, sys, time, threading, socket
import requests
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent / "ledger"))
import kukia_wallet as WALLET

# Se puede apuntar a otro Core para pruebas: KUKIA_CORE=http://127.0.0.1:8403
CORE = os.environ.get("KUKIA_CORE", "http://127.0.0.1:8300")

# ARREGLO 2026-10-19: antes cada arranque registraba un nodo NUEVO (uuid) y los
# KIA ganados se quedaban en ese id, no en la billetera. Ahora:
#  - el nodo se registra con direccion_cobro = direccion de la billetera,
#  - el id se guarda en identidad_minero.json y se reutiliza al rearrancar,
#  - al arrancar se barren a la billetera los saldos viejos de nodos que
#    firmaban con la misma clave (recupera lo que quedo huerfano).
IDENTIDAD = Path(__file__).parent / "identidad_minero.json"
BARRIDO_SEG = 300.0        # cada cuanto se revisan saldos huerfanos
_barrido_lock = threading.Lock()
_ultimo_barrido = 0.0

def _leer_identidad() -> dict:
    try:
        return json.loads(IDENTIDAD.read_text(encoding="utf-8"))
    except Exception:
        return {}

def _guardar_identidad(device: str, nid: str, pubkey: str):
    d = _leer_identidad()
    d[device] = {"id": nid, "clave_publica": pubkey}
    try:
        IDENTIDAD.write_text(json.dumps(d, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        print(f"[KUKIA] no pude guardar la identidad: {e}", flush=True)

def _registrar_o_reusar(etiqueta: str, device: str, vram_gb: int, tops: float,
                        pubkey: str, direccion: str):
    """Reutiliza el nodo de un arranque anterior si sigue existiendo en el Core."""
    guardado = _leer_identidad().get(device) or {}
    nid = guardado.get("id")
    if nid and guardado.get("clave_publica") == pubkey:
        try:
            nodos = requests.get(f"{CORE}/nodos", timeout=30).json()
            if any(n.get("id") == nid for n in nodos):
                print(f"[KUKIA] nodo {nid} ({etiqueta}) identidad reutilizada", flush=True)
                return nid
        except Exception:
            pass
    r = requests.post(f"{CORE}/nodos/registrar",
                      json={"nombre": etiqueta, "vram_gb": vram_gb, "tops": tops,
                            "clave_publica": pubkey, "direccion_cobro": direccion},
                      timeout=30)
    r.raise_for_status()
    nid = r.json()["id"]
    _guardar_identidad(device, nid, pubkey)
    print(f"[KUKIA] nodo {nid} ({etiqueta}) vram={vram_gb}GB listo (cobra en {direccion})", flush=True)
    return nid

def _asegurar_cobro(nid: str, etiqueta: str, direccion: str, privkey: str):
    """Deja el nodo pagando a la billetera (tambien si se reutilizo uno viejo)."""
    if not (direccion and privkey):
        return
    try:
        nodos = requests.get(f"{CORE}/nodos", timeout=30).json()
        actual = next((n for n in nodos if n.get("id") == nid), None)
        if not actual:
            return
        if (actual.get("direccion_cobro") or "").strip().upper() == direccion.upper():
            return
        ts = int(time.time())
        firma = WALLET.firmar(f"cobro:{nid}:{direccion}:{ts}", privkey)
        r = requests.post(f"{CORE}/nodos/{nid}/cobro",
                          json={"direccion": direccion, "ts": ts, "firma": firma}, timeout=30)
        if r.status_code == 200:
            print(f"[KUKIA] {etiqueta} cobro actualizado -> {direccion}", flush=True)
        else:
            print(f"[KUKIA] {etiqueta} no pude fijar el cobro: {r.status_code} {r.text[:120]}", flush=True)
    except Exception as e:
        print(f"[KUKIA] {etiqueta} error fijando cobro: {e}", flush=True)

def barrer_saldos(etiqueta: str, wallet: dict, privkey: str, forzar: bool = False):
    """Mueve a la billetera el saldo que quede en nodos firmados con su clave.

    Idempotente y sin privilegios: firma cada transferencia con la clave del
    nodo. Si el Core ya paga directo a la direccion, no hay nada que barrer.
    """
    global _ultimo_barrido
    direccion = (wallet.get("direccion") or "").strip().upper()
    pubkey = wallet.get("clave_publica") or ""
    if not (direccion and pubkey and privkey):
        return
    if not forzar and time.time() - _ultimo_barrido < BARRIDO_SEG:
        return
    if not _barrido_lock.acquire(blocking=False):
        return
    try:
        _ultimo_barrido = time.time()
        nodos = requests.get(f"{CORE}/nodos", timeout=30).json()
        for n in nodos:
            if (n.get("clave_publica") or "") != pubkey:
                continue
            try:
                s = requests.get(f"{CORE}/saldo/{n['id']}", timeout=30).json().get("saldo", 0)
                monto = round(float(s), 4)
                if monto <= 0:
                    continue
                nonce = f"barrido-{n['id']}-{int(time.time() * 1000)}"
                mensaje = f"transferir:{n['id']}:{direccion}:{monto}:{nonce}"
                firma = WALLET.firmar(mensaje, privkey)
                r = requests.post(f"{CORE}/transferir",
                                  json={"de_nodo": n["id"], "a_direccion": direccion,
                                        "monto": monto, "nonce": nonce, "firma": firma},
                                  timeout=60)
                if r.status_code == 200:
                    print(f"[KUKIA] {etiqueta} barrido: {monto} KIA de {n['id']} -> {direccion}", flush=True)
                else:
                    print(f"[KUKIA] {etiqueta} barrido rechazado en {n['id']}: "
                          f"{r.status_code} {r.text[:120]}", flush=True)
            except Exception as e:
                print(f"[KUKIA] {etiqueta} barrido err en {n['id']}: {e}", flush=True)
            time.sleep(0.2)
    except Exception as e:
        print(f"[KUKIA] {etiqueta} barrido err: {e}", flush=True)
    finally:
        _barrido_lock.release()

def trabajo_local(tipo: str, params: dict, device: str = "cuda:0") -> str:
    """Calcula la tarea EXACTAMENTE como el Core (determinista)."""
    if tipo == "matriz":
        import torch
        n = int(params.get("n", 256))
        seed = int(params.get("seed", 42))
        idx = torch.arange(n, device=device, dtype=torch.float64)
        a = ((idx[:, None] * 31 + idx[None, :] * 17 + seed) % 97) - 48
        b = ((idx[:, None] * 31 + idx[None, :] * 17 + (seed + 1)) % 97) - 48
        c = float((a @ b).sum().item())
        return str(int(round(c)))
    if tipo == "checksum":
        data = str(params.get("data", "kukia"))
        return hashlib.sha256(data.encode()).hexdigest()
    if tipo == "inferencia":
        import torch
        n = int(params.get("n", 64))
        seed = int(params.get("seed", 7))
        idx = torch.arange(n, device=device, dtype=torch.float64)
        x = ((idx[:, None] * 31 + idx[None, :] * 17 + seed) % 97) - 48
        k = torch.tensor([[1.0, 2.0, 1.0], [2.0, 4.0, 1.0 * 2], [1.0, 2.0, 1.0]],
                         device=device, dtype=torch.float64)
        out = 0.0
        for i in range(3):
            for j in range(3):
                out += float((x[i:n-2+i, j:n-2+j] * k[i, j]).sum().item())
        return str(int(round(out)))
    if tipo == "difusion_calor":
        # AUDITORIA: el tipo que faltaba. La rejilla inicial tiene que ser
        # IDENTICA a la del Core (numpy default_rng), asi que se genera con
        # numpy en CPU y se pasa a la GPU para iterar en float64.
        import numpy as np
        import torch
        n = int(params.get("n", 256))
        pasos = int(params.get("pasos", 200))
        seed = int(params.get("seed", 42))
        rejilla = np.random.default_rng(seed).random((n, n))
        x = torch.from_numpy(rejilla).to(device=device, dtype=torch.float64)
        for _ in range(pasos):
            x[1:-1, 1:-1] = x[1:-1, 1:-1] + 0.2 * (
                x[:-2, 1:-1] + x[2:, 1:-1] + x[1:-1, :-2] + x[1:-1, 2:] - 4 * x[1:-1, 1:-1])
        return repr(float(x.sum().item()))
    return "tarea_no_soportada"

def _codigo(r):
    return r.status_code if r is not None else 0

def ciclo_worker(nombre: str, device: str, vram_gb: int, tops: float):
    """Un hilo por GPU: registra su nodo y mina en bucle (resultados FIRMADOS)."""
    etiqueta = f"{nombre}[{device}]"
    # Billetera propia para firmar envios (nadie puede suplantar este nodo)
    w = WALLET.crear_billetera("worker_" + nombre.replace("[", "_").replace("]", "_").replace(":", ""))
    if isinstance(w, tuple):
        w = w[0]
    pubkey = w.get("clave_publica", "")
    privkey = w.get("clave_privada", "")
    direccion = w.get("direccion", "")
    try:
        nid = _registrar_o_reusar(etiqueta, device, vram_gb, tops, pubkey, direccion)
    except Exception as e:
        print(f"[KUKIA] {etiqueta} error registro: {e}", flush=True)
        return
    _asegurar_cobro(nid, etiqueta, direccion, privkey)
    barrer_saldos(etiqueta, w, privkey, forzar=True)
    bloqueado_hasta = 0.0
    while True:
        try:
            ahora = time.time()
            # Barrido periodico (throttled a BARRIDO_SEG): si el Core paga
            # directo a la direccion no hace nada; si quedo saldo viejo en
            # algun nodo, lo mueve a la billetera.
            barrer_saldos(etiqueta, w, privkey)
            if ahora < bloqueado_hasta:
                time.sleep(min(5.0, bloqueado_hasta - ahora))
                continue
            # AUDITORIA: peticion de trabajo FIRMADA (el Core ya no acepta
            # un nodo_id sin prueba de que la clave es tuya).
            ts = int(time.time())
            firma_p = WALLET.firmar(f"pendiente:{nid}:{ts}", privkey) if privkey else ""
            rp = requests.get(f"{CORE}/tareas/pendiente",
                              params={"nodo_id": nid, "ts": ts, "firma": firma_p}, timeout=30)
            if rp.status_code == 429:
                print(f"[KUKIA] {etiqueta} limitado por el Core (429), espero 20 s", flush=True)
                bloqueado_hasta = time.time() + 20
                continue
            if rp.status_code != 200:
                print(f"[KUKIA] {etiqueta} el Core rechaza la peticion de trabajo: "
                      f"{rp.status_code} {rp.text[:120]}", flush=True)
                time.sleep(10)
                continue
            pend = rp.json().get("tarea")
            if not pend:
                barrer_saldos(etiqueta, w, privkey)
                time.sleep(3)
                continue
            t0 = time.time()
            tipo = pend["tipo"]
            metrica = trabajo_local(tipo, pend["params"], device)
            duracion_ms = (time.time() - t0) * 1000.0
            if metrica == "tarea_no_soportada":
                print(f"[KUKIA] {etiqueta} tipo '{tipo}' no implementado en este worker", flush=True)
                time.sleep(5)
                continue
            firma = WALLET.firmar(f"{pend['id']}:{metrica}", privkey) if privkey else ""
            rr = requests.post(f"{CORE}/tareas/resultado",
                               params={"tid": pend["id"], "nodo_id": nid, "metrica": metrica,
                                       "firma": firma, "device": str(device),
                                       "duracion_ms": duracion_ms},
                               timeout=3600)
            if rr.status_code == 429:
                print(f"[KUKIA] {etiqueta} Core saturado (429) al entregar, espero 20 s", flush=True)
                bloqueado_hasta = time.time() + 20
                continue
            if rr.status_code != 200:
                print(f"[KUKIA] {etiqueta} entrega rechazada: {rr.status_code} {rr.text[:140]}", flush=True)
                if rr.status_code in (429, 403):
                    bloqueado_hasta = time.time() + 30
                continue
            res = rr.json()
            if res.get("ok"):
                print(f"[KUKIA] {etiqueta} tarea {pend['id'][:8]} {tipo} -> OK +{res.get('kuki')} KIA "
                      f"({duracion_ms:.0f} ms)", flush=True)
            else:
                print(f"[KUKIA] {etiqueta} tarea {pend['id'][:8]} {tipo} -> RECHAZADO "
                      f"(esperado {res.get('esperado')}, enviado {metrica[:40]})", flush=True)
        except Exception as e:
            print(f"[KUKIA] {etiqueta} err: {e}", flush=True)
            time.sleep(5)

def main():
    nombre = sys.argv[1] if len(sys.argv) > 1 else "worker_" + socket.gethostname()
    try:
        import torch
        n_gpus = torch.cuda.device_count()
    except Exception:
        n_gpus = 0

    if n_gpus == 0:
        print("[KUKIA] Sin GPUs CUDA - usando CPU (mas lento)", flush=True)
        ciclo_worker(nombre, "cpu", 0, 0.0)
        return

    print(f"[KUKIA] {n_gpus} GPU(s) detectada(s) - minando en TODAS a la vez", flush=True)
    hilos = []
    for g in range(n_gpus):
        try:
            props = torch.cuda.get_device_properties(g)
            vram = props.total_memory // (1024**3)
            # TOPS aproximados por clase de GPU (referencia NVIDIA)
            tops_est = {8: 60.0, 12: 300.0, 16: 760.0, 24: 1300.0}.get(int(vram), 100.0)
            print(f"[KUKIA] GPU{g}: {props.name} ({vram} GB)", flush=True)
        except Exception:
            vram, tops_est = 0, 0.0
        t = threading.Thread(target=ciclo_worker, args=(nombre, f"cuda:{g}", vram, tops_est), daemon=True)
        t.start()
        hilos.append(t)
    for t in hilos:
        t.join()

if __name__ == "__main__":
    main()
