@echo off
chcp 65001 >nul 2>&1
setlocal
title KUKIA - saldo del minero
cd /d "%~dp0"

set "CORE="
if exist "core_minero.txt" (
  for /f "usebackq eol=# tokens=*" %%L in ("core_minero.txt") do (
    if not defined CORE set "CORE=%%L"
  )
)
if not defined CORE set "CORE=http://127.0.0.1:8300"
set "KUKIA_CORE=%CORE%"

python -u tools\saldo_minero.py
echo.
pause
