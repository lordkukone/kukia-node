"""Publica las metricas del Core local en el rele publico (solo lectura).

El Core NO se expone a internet: este script sale a buscar /stats y /saldos
cada pocos segundos y los empuja al Worker `publico/relay.js` con una clave.
La web publica solo puede leer.

Configuracion (dos ficheros junto a este script, NO se publican):
  relay_url.txt  -> https://<tu-rele>/   (sin barra final)
  clave.txt      -> la misma clave que el secreto KUKIA_CLAVE del Worker

Uso:
  python publicar_metricas.py            (bucle, cada 10 s)
  python publicar_metricas.py --una      (una sola vez, para probar)
"""
import collections
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

AQUI = Path(__file__).parent
IDENTIDAD = AQUI.parent / "worker" / "identidad_minero.json"
CORE = os.environ.get("KUKIA_CORE", "http://127.0.0.1:8300").rstrip("/")
INTERVALO = float(os.environ.get("KUKIA_PUBLICAR_SEG", "10"))


def leer_fichero(nombre: str) -> str:
    try:
        return (AQUI / nombre).read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def get_json(ruta: str):
    with urllib.request.urlopen(CORE + ruta, timeout=8) as r:
        return json.loads(r.read().decode("utf-8"))


# Ventana movil de tareas: sirve para que la web sepa si el minero esta
# minando AHORA (una tarea de hace 2 minutos no es "en vivo").
_hist = collections.deque()      # (momento, tareas_ok)
_ultimo_cambio = 0.0


def _gpus_de_identidad():
    """GPUs reales segun worker/identidad_minero.json (lo escribe el minero)."""
    try:
        d = json.loads(IDENTIDAD.read_text(encoding="utf-8"))
        claves = [k for k in d if re.match(r"^(cuda|cpu)", str(k))]
        return len(claves) or None
    except Exception:
        return None


def salud(nodos: list) -> dict:
    """Estado del minero calculado en local (el rele no ve tu Core)."""
    global _ultimo_cambio
    ahora = time.time()
    ok = float(_hist[-1][1]) if _hist else 0.0
    base = _hist[0][1] if _hist else ok
    seg = (ahora - _hist[0][0]) if _hist else 0.0
    # Tareas por minuto normalizadas a la ventana que haya (hasta 60 s).
    por_min = ((ok - base) / seg * 60.0) if seg > 1 else 0.0
    gpus = _gpus_de_identidad()
    if gpus is None:
        # Sin fichero de identidad: cuenta los nodos con nombre de GPU (puede
        # incluir nodos viejos, por eso el fichero manda cuando existe).
        gpus = len({n.get("nombre") for n in nodos
                    if re.search(r"\[(cuda|cpu):?\d*\]$", str(n.get("nombre", "")))})
    return {
        "gpus": gpus,
        "tareas_por_min": int(round(por_min)),
        "ultima_tarea_hace": int(max(0, ahora - _ultimo_cambio)) if _ultimo_cambio else None,
    }


def publicar(relay: str, clave: str) -> dict:
    global _ultimo_cambio
    stats = get_json("/stats")
    saldos = get_json("/saldos")
    nodos = get_json("/nodos")
    ok = float(stats.get("tareas_ok") or 0)
    ahora = time.time()
    if not _hist or ok != _hist[-1][1]:
        _ultimo_cambio = ahora
    _hist.append((ahora, ok))
    while _hist and ahora - _hist[0][0] > 60:
        _hist.popleft()
    cuerpo = json.dumps({
        "stats": stats,
        "salud": salud(nodos),
        "saldos": saldos.get("saldos", {}),
    }).encode("utf-8")
    req = urllib.request.Request(
        relay + "/api/publicar",
        data=cuerpo,
        method="POST",
        # User-Agent propio: el borde de Cloudflare rechaza (403) el de
        # urllib por defecto.
        headers={"content-type": "application/json",
                 "authorization": "Bearer " + clave,
                 "user-agent": "KUKIA-publicador/1.0"},
    )
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read().decode("utf-8"))


def main() -> int:
    relay = leer_fichero("relay_url.txt").rstrip("/")
    clave = leer_fichero("clave.txt")
    if not relay or not clave:
        print("[KUKIA] faltan publico/relay_url.txt o publico/clave.txt", flush=True)
        return 2
    una = "--una" in sys.argv
    print(f"[KUKIA] publicando {CORE} -> {relay} cada {INTERVALO:.0f} s", flush=True)
    estado = None
    ultimo_aviso = 0.0
    while True:
        try:
            j = publicar(relay, clave)
            ahora = time.time()
            if estado != "ok" or ahora - ultimo_aviso >= 60:
                s = get_json("/stats")
                print(f"[KUKIA] metricas publicadas: {s['nodos']} nodos, "
                      f"{s['tareas_ok']} tareas ok, {j.get('saldos')} saldos", flush=True)
                ultimo_aviso = ahora
            estado = "ok"
        except urllib.error.HTTPError as e:
            if estado != "http" or time.time() - ultimo_aviso >= 60:
                print(f"[KUKIA] el rele rechaza la publicacion: {e.code} "
                      f"(revisa clave.txt)", flush=True)
                ultimo_aviso = time.time()
            estado = "http"
        except Exception as e:
            if estado != "err" or time.time() - ultimo_aviso >= 60:
                print(f"[KUKIA] no pude publicar ({type(e).__name__}: {e}); "
                      f"el Core sigue en {CORE}", flush=True)
                ultimo_aviso = time.time()
            estado = "err"
        if una:
            return 0 if estado == "ok" else 1
        time.sleep(INTERVALO)


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    raise SystemExit(main())
