/**
 * KUKIA publico - rele de metricas.
 *
 * El Core vive en un PC sin IP publica, asi que NO se expone: un script local
 * (publicar_metricas.py) lee /stats y /saldos cada pocos segundos y los empuja
 * aqui con una clave. La web publica solo puede LEER.
 *
 *   GET  /api/metricas        -> {ts, stats:{...}, salud:{...}, saldos:{...}}
 *   GET  /api/saldo/{dir}     -> {direccion, saldo, ts}
 *   POST /api/publicar        -> escribe el estado (Authorization: Bearer <clave>)
 *
 * Binding R2: FILES (objeto estado.json).
 */

const OBJETO = 'estado.json';
const MAX_BYTES = 256 * 1024;
const MAX_SALDOS = 2000;

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, OPTIONS',
  'Access-Control-Allow-Headers': '*',
  'Access-Control-Max-Age': '600',
};

function json(obj, status = 200, extra = {}) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      ...CORS,
      ...extra,
    },
  });
}

function num(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function limpiaSaldos(v) {
  const out = {};
  if (!v || typeof v !== 'object') return out;
  let n = 0;
  for (const [k, val] of Object.entries(v)) {
    if (n >= MAX_SALDOS) break;
    if (typeof k !== 'string' || !k || k.length > 64) continue;
    const x = num(val);
    if (x === null) continue;
    out[k.toUpperCase()] = Math.round(x * 1e6) / 1e6;
    n++;
  }
  return out;
}

async function leer(env) {
  const o = await env.FILES.get(OBJETO);
  if (!o) return null;
  try {
    return JSON.parse(await o.text());
  } catch (e) {
    return null;
  }
}

function autorizado(req, env) {
  if (!env.KUKIA_CLAVE) return false;
  const dado = req.headers.get('authorization') || '';
  const esperado = 'Bearer ' + env.KUKIA_CLAVE;
  if (dado.length !== esperado.length) return false;
  let dif = 0;
  for (let i = 0; i < esperado.length; i++) {
    dif |= dado.charCodeAt(i) ^ esperado.charCodeAt(i);
  }
  return dif === 0;
}

export default {
  async fetch(req, env) {
    const url = new URL(req.url);

    if (req.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: CORS });
    }

    if (req.method === 'POST' && url.pathname === '/api/publicar') {
      if (!autorizado(req, env)) return json({ error: 'no autorizado' }, 401);
      const txt = await req.text();
      if (txt.length > MAX_BYTES) return json({ error: 'demasiado grande' }, 413);
      let d;
      try {
        d = JSON.parse(txt);
      } catch (e) {
        return json({ error: 'json invalido' }, 400);
      }
      if (!d || typeof d !== 'object' || !d.stats || typeof d.stats !== 'object') {
        return json({ error: 'faltan stats' }, 400);
      }
      const s = d.stats;
      const estado = {
        v: 1,
        ts: Math.floor(Date.now() / 1000),
        stats: {
          supply_emitido: num(s.supply_emitido),
          max_supply: num(s.max_supply),
          nodos: num(s.nodos),
          tareas_ok: num(s.tareas_ok),
          tareas_pend: num(s.tareas_pend),
        },
        salud: {
          gpus: num(d.salud && d.salud.gpus),
          tareas_por_min: num(d.salud && d.salud.tareas_por_min),
          ultima_tarea_hace: num(d.salud && d.salud.ultima_tarea_hace),
        },
        saldos: limpiaSaldos(d.saldos),
      };
      await env.FILES.put(OBJETO, JSON.stringify(estado));
      return json({ ok: true, ts: estado.ts, saldos: Object.keys(estado.saldos).length });
    }

    if (req.method === 'GET' && url.pathname === '/api/metricas') {
      const d = await leer(env);
      if (!d) return json({ error: 'sin datos todavia' }, 503);
      return json(d);
    }

    if (req.method === 'GET' && url.pathname.startsWith('/api/saldo/')) {
      const dir = decodeURIComponent(url.pathname.slice('/api/saldo/'.length)).trim().toUpperCase();
      if (!dir) return json({ error: 'falta la direccion' }, 400);
      const d = await leer(env);
      if (!d) return json({ error: 'sin datos todavia' }, 503);
      const saldo = d.saldos ? d.saldos[dir] : undefined;
      return json({
        direccion: dir,
        saldo: typeof saldo === 'number' ? saldo : 0,
        conocido: typeof saldo === 'number',
        ts: d.ts,
      });
    }

    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/api')) {
      return json({
        servicio: 'kukia-metricas',
        nota: 'solo lectura: el Core no esta expuesto a internet',
        endpoints: ['/api/metricas', '/api/saldo/{direccion}'],
      });
    }

    return json({ error: 'no encontrado' }, 404);
  },
};
